# AmoPatinhas

Sistema web para ajudar no controle e na adoção de animais em Manaus. Cada animal ganha um código
(tipo AP-2026-0001) e uma ficha com os dados de saúde, e fica fácil de achar por ONGs, clínicas e
por quem quer adotar.

É o nosso TCC do curso de Sistemas de Informação da Fametro.

## Equipe

- Kézia Beatriz Moraes de Souza
- Yan Rodrigo Pereira Lopes
- Orientadora: Prof.ª Luana Magalhães Leal

## Como o projeto está organizado

O repositório tem duas pastas:

- `backend/`: a API, feita em Node.js com Express e banco MySQL
- `frontend/`: o site, feito em Angular com Angular Material

## O que precisa ter instalado

- Node.js 24 (24.15 ou mais novo)
- MySQL 8
- Git

Atenção com a versão do Node: o Angular 22 não instala em versão antiga. Se o `npm install` do
front der erro, confere primeiro com `node -v`.

## Rodando na sua máquina

### 1. Banco

O script que cria o banco e o usuário já está em `backend/src/db/criar-banco.sql`. Antes de rodar,
troca a senha `troque_esta_senha` por uma sua:

```bash
mysql -u root -p < backend/src/db/criar-banco.sql
```

### 2. API

```bash
cd backend
npm install
cp .env.example .env
```

No Windows, o último comando é `copy .env.example .env`.

Abre o `.env`, coloca no `DB_PASSWORD` a mesma senha que você usou no script e roda:

```bash
npm run db:migrate
npm run db:seed
npm run dev
```

O `db:migrate` cria as tabelas e o `db:seed` coloca os dados de teste. Cuidado: o seed apaga o que
tiver nas tabelas antes de inserir.

Para ver se deu certo, abre http://localhost:3000/api/saude. Tem que aparecer
`{"api":"ok","banco":"ok"}`.

### 3. Site

Em outro terminal:

```bash
cd frontend
npm install
npm start
```

O site abre em http://localhost:4200. As chamadas para `/api` vão direto para a API na porta 3000
(isso está configurado no `proxy.conf.json`).

Se você só quiser mostrar as telas, sem subir banco nem API, roda `npm run start:demo`. Nesse modo o
site usa uns dados fictícios que ficam no próprio front.

## Testes

No backend:

```bash
npm test                  # testes unitários, não precisa de banco
npm run test:integracao   # testa a API de verdade, precisa do banco com migrate e seed
```

No frontend é só `npm test`.

## Rotas da API (até agora)

- `GET /api/saude`: diz se a API e o banco estão no ar
- `GET /api/indicadores`: os números da página inicial (cadastrados, disponíveis, adotados,
  castrados, vacinados, ONGs e clínicas)
- `GET /api/animais`: lista os animais. Aceita os filtros `situacao`, `especie`, `porte`, `sexo`,
  `busca`, `microchip`, `pagina` e `porPagina`
- `GET /api/animais/AP-2026-0001`: ficha de um animal pelo código
- `GET /api/instituicoes`: ONGs e clínicas (dá para filtrar com `?tipo=ong` ou `?tipo=clinica`)

Quando dá erro, a API responde em JSON, por exemplo:
`{ "erro": "Nenhum animal encontrado com o código AP-2026-9999." }`

## Variáveis do .env

- `PORT`: porta da API (padrão 3000)
- `CORS_ORIGIN`: endereço do front que pode chamar a API
- `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASSWORD` e `DB_NAME`: dados de acesso ao MySQL
- `DADOS_DEMONSTRATIVOS`: deixa `true` enquanto o banco só tiver os dados de teste. Assim o site
  mostra o aviso de que os dados são fictícios

O `.env` tem senha, então não vai para o Git (ele já está no `.gitignore`).

## O que já está pronto

- Página inicial com busca, indicadores, animais para adoção e as ONGs e clínicas
- Lista de adoção e busca geral, com filtros e paginação
- Ficha do animal com características, histórico de saúde e quem é o responsável
- Página de ONGs e clínicas
- Banco com as tabelas principais: usuários, instituições, animais, responsáveis, saúde, adoções e
  denúncias
- Regras de mudança de status da adoção e da denúncia. Já estão testadas, só falta ligar nas telas

## O que falta (pelo cronograma)

- Semana 09 (19/10 a 25/10): login, cadastro e permissões por perfil
- Semana 10 (26/10 a 01/11): cadastro e edição de animais, fotos e registros de saúde
- Semana 11 (02/11 a 08/11): pedido de adoção, perdidos e encontrados, resgates
- Semana 12 (09/11 a 15/11): denúncias e LGPD
- Semana 13 (16/11 a 22/11): painel administrativo, relatórios e mapa
- Semana 14 (23/11 a 29/11): testes com usuários e questionário SUS

Por enquanto, os botões dessas partes levam para uma página avisando que ainda está em
desenvolvimento e quando deve ficar pronto.

## Algumas decisões do projeto

- O backend segue as mesmas camadas do nosso diagrama de sequência: rota, controlador, serviço,
  repositório e banco.
- Por causa da LGPD, o número completo do microchip não sai da API (só os 4 últimos dígitos), e os
  dados pessoais do tutor também não aparecem no site.
- Os dados de teste são todos inventados. As instituições têm "Exemplo" no nome, os e-mails são
  @example.org e os microchips começam com 999, que é a faixa reservada para teste.
- Usamos a fonte Atkinson Hyperlegible porque ela foi feita para facilitar a leitura de quem tem
  baixa visão. O site também tem foco visível no teclado, link de "pular para o conteúdo" e rótulo
  em todos os campos.
- As fontes e os ícones ficam dentro do projeto, sem depender de serviço externo.

## Versões que estamos usando

Angular 22.2, Angular Material 22.2, TypeScript 6.0, Node.js 24, Express 5.2, Knex 3.3,
MySQL 8.0, Zod 4.6, Jest 30 e Vitest 5.

## Git

Se o repositório ainda não foi iniciado:

```bash
git init
git add .
git commit -m "primeira versão: api, banco e telas públicas"
```
