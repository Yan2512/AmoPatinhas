// O repositório é substituído por um dublê: o teste verifica só a regra do serviço, sem banco.
jest.mock('../../src/repositories/animais.repository');
jest.mock('../../src/config/env', () => ({ dadosDemonstrativos: true }));

const animaisRepository = require('../../src/repositories/animais.repository');
const animaisService = require('../../src/services/animais.service');

const linhaBase = {
  id: 7,
  codigo: 'AP-2026-0007',
  nome: 'Juma',
  especie: 'cachorro',
  raca: null,
  sexo: 'femea',
  idade_estimada_meses: 96,
  porte: 'grande',
  cor: 'Dourada',
  situacao: 'disponivel',
  bairro: 'Tarumã',
  foto_url: null,
  caracteristicas: null,
  descricao: 'Idosa e muito dócil.',
  microchip: '999000000000007',
  data_resgate: '2025-11-30',
};

describe('animaisService.listar', () => {
  test('converte as linhas do banco e calcula a paginação', async () => {
    animaisRepository.listar.mockResolvedValue({
      itens: [{ ...linhaBase, castrado: 1, vacinado: 0 }],
      total: 25,
    });

    const resposta = await animaisService.listar({ pagina: 2, porPagina: 12 });

    expect(resposta.itens[0]).toMatchObject({ codigo: 'AP-2026-0007', castrado: true, vacinado: false });
    expect(resposta.itens[0]).not.toHaveProperty('microchip');
    expect(resposta.paginacao).toEqual({ pagina: 2, porPagina: 12, total: 25, totalPaginas: 3 });
    expect(resposta.dadosDemonstrativos).toBe(true);
  });
});

describe('animaisService.obterPorCodigo', () => {
  test('mostra apenas os quatro últimos dígitos do microchip', async () => {
    animaisRepository.buscarPorCodigo.mockResolvedValue({
      animal: linhaBase,
      registrosSaude: [{ tipo: 'castracao', descricao: 'Castração', data: '2025-12-20' }],
      vinculoAtual: null,
    });

    const { animal } = await animaisService.obterPorCodigo('ap-2026-0007');

    expect(animaisRepository.buscarPorCodigo).toHaveBeenCalledWith('AP-2026-0007');
    expect(animal.possuiMicrochip).toBe(true);
    expect(animal.microchipFinal).toBe('0007');
    expect(JSON.stringify(animal)).not.toContain('999000000000007');
    expect(animal.castrado).toBe(true);
    expect(animal.vacinado).toBe(false);
  });

  test('não expõe dados pessoais quando o responsável é um tutor', async () => {
    animaisRepository.buscarPorCodigo.mockResolvedValue({
      animal: linhaBase,
      registrosSaude: [],
      vinculoAtual: { tipo: 'tutor', inicio: '2026-08-09', instituicao_nome: null },
    });

    const { animal } = await animaisService.obterPorCodigo('AP-2026-0007');

    expect(animal.responsavel).toEqual({ tipo: 'tutor', desde: '2026-08-09' });
  });

  test('retorna erro 404 quando o código não existe', async () => {
    animaisRepository.buscarPorCodigo.mockResolvedValue(null);

    await expect(animaisService.obterPorCodigo('AP-2026-9999')).rejects.toMatchObject({
      status: 404,
      message: 'Nenhum animal encontrado com o código AP-2026-9999.',
    });
  });
});
