const {
  podeMudarStatusAdocao,
  podeMudarStatusDenuncia,
} = require('../../src/domain/transicoes');

describe('Regras de transição da adoção', () => {
  test('a ONG pode colocar um pedido pendente em análise', () => {
    expect(podeMudarStatusAdocao('pendente', 'em_analise', 'ong')).toBe(true);
  });

  test('um pedido pendente não pode ser aprovado sem passar pela análise', () => {
    expect(podeMudarStatusAdocao('pendente', 'aprovada', 'ong')).toBe(false);
  });

  test('pedido aprovado ou recusado não muda mais de status', () => {
    expect(podeMudarStatusAdocao('aprovada', 'recusada', 'admin')).toBe(false);
    expect(podeMudarStatusAdocao('recusada', 'em_analise', 'admin')).toBe(false);
  });

  test('tutor não pode alterar o status de um pedido', () => {
    expect(podeMudarStatusAdocao('em_analise', 'aprovada', 'tutor')).toBe(false);
  });
});

describe('Regras de transição da denúncia', () => {
  test('somente o administrador analisa denúncias', () => {
    expect(podeMudarStatusDenuncia('registrada', 'em_analise', 'admin')).toBe(true);
    expect(podeMudarStatusDenuncia('registrada', 'em_analise', 'ong')).toBe(false);
  });

  test('denúncia encerrada não pode ser reaberta', () => {
    expect(podeMudarStatusDenuncia('encerrada', 'em_analise', 'admin')).toBe(false);
  });

  test('status desconhecido nunca é aceito', () => {
    expect(podeMudarStatusDenuncia('inexistente', 'encerrada', 'admin')).toBe(false);
  });
});
