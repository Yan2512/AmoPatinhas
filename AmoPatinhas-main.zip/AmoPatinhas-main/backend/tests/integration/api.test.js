/**
 * Testes de integração: usam o MySQL configurado no .env.
 * Antes de rodar: npm run db:migrate && npm run db:seed
 * Os testes apenas leem dados; nada é alterado no banco.
 */
const request = require('supertest');
const app = require('../../src/app');
const db = require('../../src/db/conexao');

afterAll(() => db.destroy());

describe('API do AmoPatinhas', () => {
  test('GET /api/saude confirma API e banco', async () => {
    const resposta = await request(app).get('/api/saude');
    expect(resposta.status).toBe(200);
    expect(resposta.body).toEqual({ api: 'ok', banco: 'ok' });
  });

  test('GET /api/indicadores devolve números calculados no banco', async () => {
    const resposta = await request(app).get('/api/indicadores');
    expect(resposta.status).toBe(200);
    const { indicadores } = resposta.body;
    for (const valor of Object.values(indicadores)) {
      expect(Number.isInteger(valor)).toBe(true);
    }
    expect(indicadores.disponiveisAdocao).toBeLessThanOrEqual(indicadores.animaisCadastrados);
  });

  test('GET /api/animais filtra por situação e pagina o resultado', async () => {
    const resposta = await request(app).get('/api/animais?situacao=disponivel&porPagina=4');
    expect(resposta.status).toBe(200);
    expect(resposta.body.itens.length).toBeLessThanOrEqual(4);
    expect(resposta.body.itens.every((animal) => animal.situacao === 'disponivel')).toBe(true);
    expect(resposta.body.paginacao.porPagina).toBe(4);
  });

  test('GET /api/animais recusa filtros inválidos com status 400', async () => {
    const resposta = await request(app).get('/api/animais?especie=dinossauro');
    expect(resposta.status).toBe(400);
    expect(resposta.body.detalhes[0].campo).toBe('especie');
  });

  test('GET /api/animais/:codigo devolve a ficha sem o microchip completo', async () => {
    const lista = await request(app).get('/api/animais?porPagina=1');
    const codigo = lista.body.itens[0].codigo;

    const resposta = await request(app).get(`/api/animais/${codigo}`);
    expect(resposta.status).toBe(200);
    expect(resposta.body.animal.codigo).toBe(codigo);
    expect(resposta.body.animal).not.toHaveProperty('microchip');
    expect(Array.isArray(resposta.body.animal.historicoSaude)).toBe(true);
  });

  test('GET /api/animais/:codigo responde 404 para código inexistente', async () => {
    const resposta = await request(app).get('/api/animais/AP-1900-0001');
    expect(resposta.status).toBe(404);
  });

  test('GET /api/instituicoes filtra por tipo', async () => {
    const resposta = await request(app).get('/api/instituicoes?tipo=clinica');
    expect(resposta.status).toBe(200);
    expect(resposta.body.itens.every((item) => item.tipo === 'clinica')).toBe(true);
  });

  test('rota inexistente responde 404 em JSON', async () => {
    const resposta = await request(app).get('/api/nao-existe');
    expect(resposta.status).toBe(404);
    expect(resposta.body.erro).toContain('Rota não encontrada');
  });
});
