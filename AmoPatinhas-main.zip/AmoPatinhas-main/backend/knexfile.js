/**
 * Configuração do Knex, usada pela API e pela linha de comando
 * (npm run db:migrate, npm run db:seed).
 */
const config = require('./src/config/env');

module.exports = {
  client: 'mysql2',
  connection: {
    ...config.banco,
    charset: 'utf8mb4',
    // Datas (DATE) chegam como texto "AAAA-MM-DD", sem conversão de fuso horário.
    dateStrings: true,
  },
  pool: { min: 0, max: 10 },
  migrations: {
    directory: './src/db/migrations',
    tableName: 'knex_migrations',
  },
  seeds: {
    directory: './src/db/seeds',
  },
};
