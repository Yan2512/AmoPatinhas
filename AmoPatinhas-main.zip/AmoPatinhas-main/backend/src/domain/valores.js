/**
 * Valores aceitos pelo domínio do AmoPatinhas.
 * Os validadores e as regras de negócio usam estas listas; as migrations
 * guardam uma cópia própria, porque descrevem o banco no momento em que foram criadas.
 */
const ESPECIES = ['cachorro', 'gato', 'outro'];
const SEXOS = ['macho', 'femea', 'desconhecido'];
const PORTES = ['pequeno', 'medio', 'grande'];
const SITUACOES_ANIMAL = [
  'disponivel',
  'em_tratamento',
  'com_tutor',
  'adotado',
  'perdido',
  'encontrado',
];
const TIPOS_REGISTRO_SAUDE = [
  'vacina',
  'castracao',
  'tratamento',
  'doenca',
  'alergia',
  'procedimento',
];
const TIPOS_INSTITUICAO = ['ong', 'clinica'];
const PERFIS_USUARIO = ['tutor', 'ong', 'clinica', 'admin'];
const STATUS_ADOCAO = ['pendente', 'em_analise', 'aprovada', 'recusada'];
const STATUS_DENUNCIA = ['registrada', 'em_analise', 'encaminhada', 'encerrada'];
const CATEGORIAS_DENUNCIA = [
  'maus_tratos',
  'abandono',
  'situacao_risco',
  'criacao_ilegal',
  'trafico',
  'outros',
];

module.exports = {
  ESPECIES,
  SEXOS,
  PORTES,
  SITUACOES_ANIMAL,
  TIPOS_REGISTRO_SAUDE,
  TIPOS_INSTITUICAO,
  PERFIS_USUARIO,
  STATUS_ADOCAO,
  STATUS_DENUNCIA,
  CATEGORIAS_DENUNCIA,
};
