/**
 * Regras de transição de status (regras de negócio da adoção e da denúncia).
 * Ficam em um módulo puro, sem banco, para serem testadas isoladamente e
 * reaproveitadas pelos serviços quando os módulos de adoção (semana 11) e
 * de denúncias (semana 12) forem implementados.
 */

const TRANSICOES_ADOCAO = {
  pendente: ['em_analise', 'recusada'],
  em_analise: ['aprovada', 'recusada'],
  aprovada: [],
  recusada: [],
};

const TRANSICOES_DENUNCIA = {
  registrada: ['em_analise'],
  em_analise: ['encaminhada', 'encerrada'],
  encaminhada: ['encerrada'],
  encerrada: [],
};

/** Quais perfis podem mudar o status de cada processo. */
const PERFIS_AUTORIZADOS = {
  adocao: ['ong', 'admin'],
  denuncia: ['admin'],
};

function podeTransitar(mapa, atual, proximo) {
  return Boolean(mapa[atual] && mapa[atual].includes(proximo));
}

function podeMudarStatusAdocao(atual, proximo, perfil) {
  return PERFIS_AUTORIZADOS.adocao.includes(perfil) && podeTransitar(TRANSICOES_ADOCAO, atual, proximo);
}

function podeMudarStatusDenuncia(atual, proximo, perfil) {
  return (
    PERFIS_AUTORIZADOS.denuncia.includes(perfil) && podeTransitar(TRANSICOES_DENUNCIA, atual, proximo)
  );
}

module.exports = {
  TRANSICOES_ADOCAO,
  TRANSICOES_DENUNCIA,
  PERFIS_AUTORIZADOS,
  podeMudarStatusAdocao,
  podeMudarStatusDenuncia,
};
