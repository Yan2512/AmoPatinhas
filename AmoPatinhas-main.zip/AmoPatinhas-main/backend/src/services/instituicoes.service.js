const instituicoesRepository = require('../repositories/instituicoes.repository');
const config = require('../config/env');

function paraInstituicao(linha) {
  return {
    id: linha.id,
    tipo: linha.tipo,
    nome: linha.nome,
    descricao: linha.descricao,
    servicos: linha.servicos
      ? linha.servicos.split(';').map((servico) => servico.trim()).filter(Boolean)
      : [],
    bairro: linha.bairro,
    endereco: linha.endereco,
    telefone: linha.telefone,
    email: linha.email,
    site: linha.site,
    horario: linha.horario,
    animaisSobCuidado: Number(linha.animais_sob_cuidado || 0),
  };
}

async function listar(filtros) {
  const linhas = await instituicoesRepository.listar(filtros);
  return {
    itens: linhas.map(paraInstituicao),
    dadosDemonstrativos: config.dadosDemonstrativos,
  };
}

module.exports = { listar };
