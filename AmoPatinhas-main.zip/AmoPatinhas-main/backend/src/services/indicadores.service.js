const indicadoresRepository = require('../repositories/indicadores.repository');
const config = require('../config/env');

async function obter() {
  const indicadores = await indicadoresRepository.contar();
  return {
    indicadores,
    geradoEm: new Date().toISOString(),
    dadosDemonstrativos: config.dadosDemonstrativos,
  };
}

module.exports = { obter };
