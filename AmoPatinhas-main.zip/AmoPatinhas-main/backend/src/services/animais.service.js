const animaisRepository = require('../repositories/animais.repository');
const config = require('../config/env');
const { ErroApp } = require('../utils/erro-app');

function paraResumo(linha) {
  return {
    codigo: linha.codigo,
    nome: linha.nome,
    especie: linha.especie,
    raca: linha.raca,
    sexo: linha.sexo,
    idadeEstimadaMeses: linha.idade_estimada_meses,
    porte: linha.porte,
    cor: linha.cor,
    situacao: linha.situacao,
    bairro: linha.bairro,
    fotoUrl: linha.foto_url,
    castrado: Boolean(Number(linha.castrado)),
    vacinado: Boolean(Number(linha.vacinado)),
  };
}

/**
 * Privacidade (LGPD): o número completo do microchip não é exposto.
 * A página pública mostra apenas se existe microchip e os quatro últimos dígitos.
 */
function finalDoMicrochip(microchip) {
  return microchip ? microchip.slice(-4) : null;
}

/**
 * Dados de contato só são exibidos quando o responsável é uma instituição.
 * Quando é um tutor (pessoa física), nenhum dado pessoal é enviado.
 */
function paraResponsavel(vinculo) {
  if (!vinculo) return null;
  if (vinculo.tipo === 'tutor') {
    return { tipo: 'tutor', desde: vinculo.inicio };
  }
  return {
    tipo: 'instituicao',
    desde: vinculo.inicio,
    nome: vinculo.instituicao_nome,
    tipoInstituicao: vinculo.instituicao_tipo,
    bairro: vinculo.instituicao_bairro,
    telefone: vinculo.instituicao_telefone,
    email: vinculo.instituicao_email,
  };
}

async function listar(filtros) {
  const { itens, total } = await animaisRepository.listar(filtros);
  return {
    itens: itens.map(paraResumo),
    paginacao: {
      pagina: filtros.pagina,
      porPagina: filtros.porPagina,
      total,
      totalPaginas: Math.max(1, Math.ceil(total / filtros.porPagina)),
    },
    dadosDemonstrativos: config.dadosDemonstrativos,
  };
}

async function obterPorCodigo(codigo) {
  const resultado = await animaisRepository.buscarPorCodigo(codigo.toUpperCase());

  if (!resultado) {
    throw new ErroApp(404, `Nenhum animal encontrado com o código ${codigo.toUpperCase()}.`);
  }

  const { animal, registrosSaude, vinculoAtual } = resultado;
  const tipos = new Set(registrosSaude.map((registro) => registro.tipo));

  return {
    animal: {
      ...paraResumo({
        ...animal,
        castrado: tipos.has('castracao'),
        vacinado: tipos.has('vacina'),
      }),
      caracteristicas: animal.caracteristicas,
      descricao: animal.descricao,
      dataResgate: animal.data_resgate,
      possuiMicrochip: Boolean(animal.microchip),
      microchipFinal: finalDoMicrochip(animal.microchip),
      historicoSaude: registrosSaude,
      responsavel: paraResponsavel(vinculoAtual),
    },
    dadosDemonstrativos: config.dadosDemonstrativos,
  };
}

module.exports = { listar, obterPorCodigo, finalDoMicrochip };
