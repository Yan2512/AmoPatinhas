const saudeRepository = require('../repositories/saude.repository');

async function verificar() {
  try {
    await saudeRepository.verificarConexao();
    return { api: 'ok', banco: 'ok' };
  } catch (erro) {
    return { api: 'ok', banco: 'indisponível', motivo: erro.code || erro.message };
  }
}

module.exports = { verificar };
