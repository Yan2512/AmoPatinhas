/**
 * Escapa os caracteres especiais do LIKE (% e _) para que o texto digitado
 * pelo usuário seja procurado literalmente.
 */
function escaparLike(texto) {
  return texto.replace(/[\\%_]/g, (caractere) => `\\${caractere}`);
}

module.exports = { escaparLike };
