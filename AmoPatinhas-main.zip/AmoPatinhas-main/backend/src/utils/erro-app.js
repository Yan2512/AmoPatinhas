/**
 * Erro "esperado" da aplicação: carrega o status HTTP e uma mensagem
 * que pode ser exibida ao usuário. Erros de qualquer outro tipo são
 * tratados como falha interna pelo middleware de erros.
 */
class ErroApp extends Error {
  constructor(status, mensagem, detalhes) {
    super(mensagem);
    this.name = 'ErroApp';
    this.status = status;
    this.detalhes = detalhes;
  }
}

module.exports = { ErroApp };
