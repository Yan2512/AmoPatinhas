-- Rode uma única vez, como administrador do MySQL (ex.: mysql -u root -p < src/db/criar-banco.sql).
-- Troque a senha abaixo e use a mesma no arquivo .env (DB_PASSWORD).
CREATE DATABASE IF NOT EXISTS amopatinhas
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

CREATE USER IF NOT EXISTS 'amopatinhas'@'localhost' IDENTIFIED BY '82309048';
GRANT ALL PRIVILEGES ON amopatinhas.* TO 'amopatinhas'@'localhost';
FLUSH PRIVILEGES;
