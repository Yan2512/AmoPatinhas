const knex = require('knex');
const configuracao = require('../../knexfile');

/** Conexão única com o banco, compartilhada por todos os repositórios. */
const db = knex(configuracao);

module.exports = db;
