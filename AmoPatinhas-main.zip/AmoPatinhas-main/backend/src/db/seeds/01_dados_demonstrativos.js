/**
 * DADOS FICTÍCIOS PARA DEMONSTRAÇÃO E TESTES.
 *
 * Nenhum animal, instituição ou pessoa deste arquivo existe. Os nomes das
 * instituições contêm "Exemplo", os e-mails usam o domínio reservado example.org
 * e os microchips começam com 999, faixa reservada a transponders de teste
 * (ISO 11784). Com DADOS_DEMONSTRATIVOS=true no .env, a API avisa o front-end,
 * que exibe o aviso "Dados demonstrativos" nas telas.
 *
 * Atenção: este seed apaga os dados das tabelas antes de inserir.
 */

const instituicoes = [
  {
    id: 1, tipo: 'ong', nome: 'Abrigo Exemplo Rio Negro', bairro: 'Compensa',
    descricao: 'Acolhe cães e gatos resgatados na Zona Oeste e organiza feiras de adoção.',
    servicos: 'Resgate; Adoção; Lar temporário', horario: 'Segunda a sábado, das 8h às 17h',
    telefone: '(92) 90000-0001', email: 'contato.rionegro@example.org',
  },
  {
    id: 2, tipo: 'ong', nome: 'ONG Exemplo Patas do Tarumã', bairro: 'Tarumã',
    descricao: 'Resgata animais em situação de rua e mantém mutirões de castração.',
    servicos: 'Resgate; Castração; Educação', horario: 'Terça a sábado, das 9h às 16h',
    telefone: '(92) 90000-0002', email: 'contato.taruma@example.org',
  },
  {
    id: 3, tipo: 'ong', nome: 'Coletivo Exemplo Zona Leste', bairro: 'São José Operário',
    descricao: 'Grupo de voluntários que atua com adoção e campanhas de vacinação.',
    servicos: 'Adoção; Campanhas de vacinação', horario: 'Sábados, das 8h às 12h',
    telefone: '(92) 90000-0003', email: 'contato.zonaleste@example.org',
  },
  {
    id: 4, tipo: 'ong', nome: 'Lar Temporário Exemplo Flores', bairro: 'Flores',
    descricao: 'Rede de lares temporários para filhotes e animais em recuperação.',
    servicos: 'Lar temporário; Adoção', horario: 'Atendimento com agendamento',
    telefone: '(92) 90000-0004', email: 'contato.flores@example.org',
  },
  {
    id: 5, tipo: 'clinica', nome: 'Clínica Veterinária Exemplo Adrianópolis', bairro: 'Adrianópolis',
    descricao: 'Clínica geral para cães e gatos.',
    servicos: 'Consultas; Vacinação; Castração', horario: 'Segunda a sexta, das 8h às 18h',
    endereco: 'Rua Exemplo, 100', telefone: '(92) 90000-0005', email: 'clinica.adrianopolis@example.org',
  },
  {
    id: 6, tipo: 'clinica', nome: 'Hospital Veterinário Exemplo Cidade Nova', bairro: 'Cidade Nova',
    descricao: 'Atendimento de urgência, cirurgias e internação.',
    servicos: 'Atendimento 24 horas; Cirurgias; Internação', horario: 'Todos os dias, 24 horas',
    endereco: 'Avenida Exemplo, 2000', telefone: '(92) 90000-0006', email: 'hospital.cidadenova@example.org',
  },
  {
    id: 7, tipo: 'clinica', nome: 'Consultório Veterinário Exemplo Parque 10', bairro: 'Parque 10 de Novembro',
    descricao: 'Consultório de atendimento clínico e exames.',
    servicos: 'Consultas; Exames; Vacinação', horario: 'Segunda a sábado, das 8h às 14h',
    endereco: 'Travessa Exemplo, 10', telefone: '(92) 90000-0007', email: 'consultorio.parque10@example.org',
  },
];

// Contas fictícias sem login: o hash "!" não corresponde a nenhuma senha.
const usuarios = [
  { id: 1, nome: 'Tutor Demonstrativo 1', email: 'tutor1@example.org', senha_hash: '!', perfil: 'tutor' },
  { id: 2, nome: 'Tutora Demonstrativa 2', email: 'tutor2@example.org', senha_hash: '!', perfil: 'tutor' },
];

const animais = [
  { id: 1, codigo: 'AP-2026-0001', nome: 'Tucumã', especie: 'cachorro', raca: null, sexo: 'macho', idade_estimada_meses: 24, porte: 'medio', cor: 'Caramelo', caracteristicas: 'Pelagem curta e orelhas em pé', descricao: 'Resgatado perto da feira da Compensa. Brincalhão, se dá bem com outros cães e com crianças.', situacao: 'disponivel', microchip: '999000000000001', bairro: 'Compensa', data_resgate: '2026-03-12' },
  { id: 2, codigo: 'AP-2026-0002', nome: 'Açaí', especie: 'gato', raca: null, sexo: 'femea', idade_estimada_meses: 8, porte: 'pequeno', cor: 'Preta', caracteristicas: 'Olhos amarelos', descricao: 'Tranquila e curiosa. Gosta de colo e de ficar perto da janela.', situacao: 'disponivel', microchip: null, bairro: 'Flores', data_resgate: '2026-06-02' },
  { id: 3, codigo: 'AP-2026-0003', nome: 'Jambu', especie: 'cachorro', raca: null, sexo: 'macho', idade_estimada_meses: 48, porte: 'grande', cor: 'Preto e branco', caracteristicas: 'Pelagem média', descricao: 'Calmo, ótimo para casas com quintal. Já sabe passear na guia.', situacao: 'disponivel', microchip: '999000000000003', bairro: 'Tarumã', data_resgate: '2026-01-20' },
  { id: 4, codigo: 'AP-2026-0004', nome: 'Tainá', especie: 'cachorro', raca: null, sexo: 'femea', idade_estimada_meses: 14, porte: 'medio', cor: 'Tigrada', caracteristicas: null, descricao: 'Sociável e cheia de energia. Precisa de alguém que goste de caminhar.', situacao: 'disponivel', microchip: null, bairro: 'São José Operário', data_resgate: '2026-05-15' },
  { id: 5, codigo: 'AP-2026-0005', nome: 'Cupuaçu', especie: 'gato', raca: null, sexo: 'macho', idade_estimada_meses: 30, porte: 'medio', cor: 'Laranja rajado', caracteristicas: null, descricao: 'Independente e carinhoso no tempo dele. Convive bem com outros gatos.', situacao: 'disponivel', microchip: '999000000000005', bairro: 'Compensa', data_resgate: '2026-02-08' },
  { id: 6, codigo: 'AP-2026-0006', nome: 'Iara', especie: 'gato', raca: 'Siamês (mestiça)', sexo: 'femea', idade_estimada_meses: 18, porte: 'pequeno', cor: 'Creme com extremidades escuras', caracteristicas: null, descricao: 'Delicada e observadora. Combina com apartamento.', situacao: 'disponivel', microchip: null, bairro: 'Flores', data_resgate: '2026-04-11' },
  { id: 7, codigo: 'AP-2026-0007', nome: 'Juma', especie: 'cachorro', raca: 'Labrador (mestiça)', sexo: 'femea', idade_estimada_meses: 96, porte: 'grande', cor: 'Dourada', caracteristicas: 'Focinho grisalho', descricao: 'Idosa e muito dócil. Procura um lar tranquilo para envelhecer.', situacao: 'disponivel', microchip: '999000000000007', bairro: 'Tarumã', data_resgate: '2025-11-30' },
  { id: 8, codigo: 'AP-2026-0008', nome: 'Guaraná', especie: 'cachorro', raca: null, sexo: 'macho', idade_estimada_meses: 5, porte: 'pequeno', cor: 'Marrom', caracteristicas: null, descricao: 'Filhote esperto. Ainda vai completar o esquema de vacinas.', situacao: 'disponivel', microchip: null, bairro: 'São José Operário', data_resgate: '2026-08-20' },
  { id: 9, codigo: 'AP-2026-0009', nome: 'Paçoca', especie: 'outro', raca: 'Coelho mestiço', sexo: 'femea', idade_estimada_meses: 12, porte: 'pequeno', cor: 'Bege', caracteristicas: null, descricao: 'Coelha dócil, acostumada a ser pega no colo. Precisa de espaço seguro e feno à vontade.', situacao: 'disponivel', microchip: null, bairro: 'Flores', data_resgate: '2026-07-03' },
  { id: 10, codigo: 'AP-2026-0010', nome: 'Boto', especie: 'cachorro', raca: null, sexo: 'macho', idade_estimada_meses: 36, porte: 'medio', cor: 'Cinza', caracteristicas: 'Uma orelha caída', descricao: 'Desconfiado no início e muito apegado depois. Melhor em casa sem outros cães machos.', situacao: 'disponivel', microchip: '999000000000010', bairro: 'Compensa', data_resgate: '2026-02-25' },
  { id: 11, codigo: 'AP-2026-0011', nome: 'Piri', especie: 'gato', raca: null, sexo: 'macho', idade_estimada_meses: 4, porte: 'pequeno', cor: 'Cinza rajado', caracteristicas: null, descricao: 'Filhote resgatado da chuva. Em tratamento de verminose.', situacao: 'em_tratamento', microchip: null, bairro: 'Tarumã', data_resgate: '2026-09-15' },
  { id: 12, codigo: 'AP-2026-0012', nome: 'Aurora', especie: 'cachorro', raca: null, sexo: 'femea', idade_estimada_meses: 20, porte: 'medio', cor: 'Branca', caracteristicas: null, descricao: 'Em recuperação de cirurgia na pata traseira.', situacao: 'em_tratamento', microchip: null, bairro: 'Cidade Nova', data_resgate: '2026-08-28' },
  { id: 13, codigo: 'AP-2026-0013', nome: 'Caju', especie: 'cachorro', raca: null, sexo: 'macho', idade_estimada_meses: 26, porte: 'medio', cor: 'Caramelo e branco', caracteristicas: null, descricao: 'Adotado em agosto de 2026.', situacao: 'adotado', microchip: '999000000000013', bairro: 'Flores', data_resgate: '2026-02-14' },
  { id: 14, codigo: 'AP-2026-0014', nome: 'Mel', especie: 'gato', raca: null, sexo: 'femea', idade_estimada_meses: 15, porte: 'pequeno', cor: 'Tricolor', caracteristicas: null, descricao: 'Adotada em julho de 2026.', situacao: 'adotado', microchip: null, bairro: 'Compensa', data_resgate: '2026-03-30' },
  { id: 15, codigo: 'AP-2026-0015', nome: 'Bento', especie: 'cachorro', raca: 'Pinscher (mestiço)', sexo: 'macho', idade_estimada_meses: 40, porte: 'pequeno', cor: 'Preto e marrom', caracteristicas: null, descricao: 'Adotado em setembro de 2026.', situacao: 'adotado', microchip: '999000000000015', bairro: 'Tarumã', data_resgate: '2026-01-05' },
  { id: 16, codigo: 'AP-2026-0016', nome: 'Nina', especie: 'gato', raca: null, sexo: 'femea', idade_estimada_meses: 60, porte: 'medio', cor: 'Cinza', caracteristicas: null, descricao: 'Vive com a tutora no Parque 10.', situacao: 'com_tutor', microchip: '999000000000016', bairro: 'Parque 10 de Novembro', data_resgate: null },
  { id: 17, codigo: 'AP-2026-0017', nome: 'Pipoca', especie: 'cachorro', raca: 'Shih-tzu', sexo: 'macho', idade_estimada_meses: 84, porte: 'pequeno', cor: 'Branco e dourado', caracteristicas: 'Usa coleira vermelha', descricao: 'Desapareceu perto do Parque dos Bilhares. Tem microchip.', situacao: 'perdido', microchip: '999000000000017', bairro: 'Chapada', data_resgate: null },
  { id: 18, codigo: 'AP-2026-0018', nome: null, especie: 'cachorro', raca: null, sexo: 'femea', idade_estimada_meses: null, porte: 'medio', cor: 'Preta', caracteristicas: 'Coleira azul sem identificação', descricao: 'Encontrada na Avenida Djalma Batista. Aguarda o tutor ou um novo destino.', situacao: 'encontrado', microchip: null, bairro: 'Chapada', data_resgate: '2026-10-05' },
];

const vinculos = [
  // Animais sob cuidado de ONGs (vínculo atual: fim nulo)
  ...[
    [1, 1], [2, 4], [3, 2], [4, 3], [5, 1], [6, 4], [7, 2], [8, 3], [9, 4], [10, 1], [11, 2], [12, 3], [18, 1],
  ].map(([animal, instituicao]) => ({
    animal_id: animal,
    tipo: 'instituicao',
    instituicao_id: instituicao,
    inicio: animais[animal - 1].data_resgate,
    fim: null,
  })),
  // Adoções: o vínculo com a ONG é encerrado e o tutor passa a ser o responsável
  { animal_id: 13, tipo: 'instituicao', instituicao_id: 4, inicio: '2026-02-14', fim: '2026-08-09' },
  { animal_id: 13, tipo: 'tutor', usuario_id: 1, inicio: '2026-08-09', fim: null },
  { animal_id: 14, tipo: 'instituicao', instituicao_id: 1, inicio: '2026-03-30', fim: '2026-07-18' },
  { animal_id: 14, tipo: 'tutor', usuario_id: 2, inicio: '2026-07-18', fim: null },
  { animal_id: 15, tipo: 'instituicao', instituicao_id: 2, inicio: '2026-01-05', fim: '2026-09-21' },
  { animal_id: 15, tipo: 'tutor', usuario_id: 1, inicio: '2026-09-21', fim: null },
  // Animais que já tinham tutor
  { animal_id: 16, tipo: 'tutor', usuario_id: 2, inicio: '2021-10-01', fim: null },
  { animal_id: 17, tipo: 'tutor', usuario_id: 1, inicio: '2019-10-01', fim: null },
];

const registrosSaude = [
  [1, 'vacina', 'V10 (polivalente canina)', '2026-03-20', 5],
  [1, 'vacina', 'Antirrábica', '2026-03-20', 5],
  [1, 'castracao', 'Castração', '2026-04-02', 5],
  [2, 'vacina', 'V4 (quádrupla felina)', '2026-06-10', 5],
  [2, 'castracao', 'Castração', '2026-07-01', 5],
  [3, 'doenca', 'Erliquiose', '2026-01-24', 6],
  [3, 'tratamento', 'Antibiótico por 28 dias para erliquiose', '2026-01-24', 6],
  [3, 'vacina', 'V10 (polivalente canina)', '2026-01-28', 6],
  [3, 'vacina', 'Antirrábica', '2026-01-28', 6],
  [3, 'castracao', 'Castração', '2026-02-10', 6],
  [4, 'vacina', 'V10 (polivalente canina)', '2026-05-25', 7],
  [4, 'castracao', 'Castração', '2026-06-15', 5],
  [5, 'vacina', 'V4 (quádrupla felina)', '2026-02-15', 5],
  [5, 'vacina', 'Antirrábica', '2026-02-15', 5],
  [5, 'castracao', 'Castração', '2026-03-01', 5],
  [5, 'alergia', 'Dermatite alérgica à picada de pulga', '2026-03-10', 5],
  [6, 'vacina', 'V4 (quádrupla felina)', '2026-04-20', 7],
  [6, 'castracao', 'Castração', '2026-05-05', 5],
  [7, 'vacina', 'V10 (polivalente canina)', '2025-12-10', 6],
  [7, 'vacina', 'Antirrábica', '2025-12-10', 6],
  [7, 'castracao', 'Castração', '2025-12-20', 6],
  [7, 'procedimento', 'Limpeza de tártaro', '2026-02-18', 7],
  [8, 'procedimento', 'Vermifugação', '2026-08-25', 7],
  [8, 'vacina', 'V10 (polivalente canina), 1ª dose', '2026-09-01', 7],
  [9, 'procedimento', 'Avaliação clínica de entrada', '2026-07-05', 7],
  [10, 'vacina', 'V10 (polivalente canina)', '2026-03-05', 5],
  [10, 'castracao', 'Castração', '2026-03-20', 5],
  [11, 'doenca', 'Verminose', '2026-09-16', 6],
  [11, 'tratamento', 'Vermifugação e suplementação', '2026-09-16', 6],
  [12, 'procedimento', 'Cirurgia ortopédica na pata traseira esquerda', '2026-09-02', 6],
  [12, 'tratamento', 'Fisioterapia semanal', '2026-09-10', 6],
  [13, 'vacina', 'V10 (polivalente canina)', '2026-02-20', 5],
  [13, 'castracao', 'Castração', '2026-03-10', 5],
  [14, 'vacina', 'V4 (quádrupla felina)', '2026-04-05', 5],
  [14, 'castracao', 'Castração', '2026-04-20', 5],
  [15, 'vacina', 'V10 (polivalente canina)', '2026-01-12', 6],
  [15, 'vacina', 'Antirrábica', '2026-01-12', 6],
  [15, 'castracao', 'Castração', '2026-02-02', 6],
  [16, 'castracao', 'Castração', '2025-06-10', 7],
  [16, 'vacina', 'V4 (quádrupla felina)', '2026-01-15', 7],
  [17, 'vacina', 'V10 (polivalente canina)', '2026-05-02', 5],
  [17, 'vacina', 'Antirrábica', '2026-05-02', 5],
  [18, 'procedimento', 'Avaliação clínica de entrada', '2026-10-06', 6],
].map(([animal_id, tipo, descricao, data, instituicao_id]) => ({
  animal_id,
  tipo,
  descricao,
  data,
  instituicao_id,
}));

exports.seed = async function (knex) {
  await knex.transaction(async (trx) => {
    // Ordem inversa das dependências entre as tabelas
    await trx('registros_saude').del();
    await trx('vinculos_responsavel').del();
    await trx('solicitacoes_adocao').del();
    await trx('denuncias').del();
    await trx('animais').del();
    await trx('instituicoes').del();
    await trx('usuarios').del();

    await trx('usuarios').insert(usuarios);
    await trx('instituicoes').insert(instituicoes);
    await trx('animais').insert(animais);
    await trx('vinculos_responsavel').insert(vinculos);
    await trx('registros_saude').insert(registrosSaude);
  });
};
