/**
 * Denúncias de maus-tratos e abandono. Nunca são expostas publicamente:
 * o acesso será restrito por perfil quando o módulo for implementado (semana 12).
 */
exports.up = function (knex) {
  return knex.schema.createTable('denuncias', (t) => {
    t.increments('id').primary();
    t.string('protocolo', 20).notNullable().unique();
    t.enu('categoria', [
      'maus_tratos',
      'abandono',
      'situacao_risco',
      'criacao_ilegal',
      'trafico',
      'outros',
    ]).notNullable();
    t.text('descricao').notNullable();
    t.date('data_ocorrencia').nullable();
    t.string('local_referencia', 255).notNullable();
    t.string('bairro', 80).nullable();
    t.string('contato_retorno', 160).nullable();
    t.integer('usuario_id').unsigned().nullable()
      .references('id').inTable('usuarios').onDelete('SET NULL');
    t.enu('status', ['registrada', 'em_analise', 'encaminhada', 'encerrada'])
      .notNullable().defaultTo('registrada');
    t.timestamp('criado_em').notNullable().defaultTo(knex.fn.now());
    t.timestamp('atualizado_em').notNullable().defaultTo(knex.fn.now());
    t.index(['status']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('denuncias');
};
