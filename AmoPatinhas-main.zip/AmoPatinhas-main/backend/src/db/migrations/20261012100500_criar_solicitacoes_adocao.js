/** Pedidos de adoção. Status: pendente, em_analise, aprovada ou recusada. */
exports.up = function (knex) {
  return knex.schema.createTable('solicitacoes_adocao', (t) => {
    t.increments('id').primary();
    t.integer('animal_id').unsigned().notNullable()
      .references('id').inTable('animais').onDelete('CASCADE');
    t.integer('usuario_id').unsigned().notNullable()
      .references('id').inTable('usuarios').onDelete('CASCADE');
    t.enu('status', ['pendente', 'em_analise', 'aprovada', 'recusada'])
      .notNullable().defaultTo('pendente');
    t.text('mensagem').nullable();
    t.integer('analisado_por').unsigned().nullable()
      .references('id').inTable('usuarios').onDelete('SET NULL');
    t.timestamp('criado_em').notNullable().defaultTo(knex.fn.now());
    t.timestamp('atualizado_em').notNullable().defaultTo(knex.fn.now());
    t.index(['animal_id', 'status']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('solicitacoes_adocao');
};
