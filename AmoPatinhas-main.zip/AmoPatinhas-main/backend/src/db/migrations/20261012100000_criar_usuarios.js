/** Contas de acesso. O perfil define as permissões (tutor, ONG, clínica, administrador). */
exports.up = function (knex) {
  return knex.schema.createTable('usuarios', (t) => {
    t.increments('id').primary();
    t.string('nome', 120).notNullable();
    t.string('email', 160).notNullable().unique();
    t.string('cpf', 11).nullable().unique();
    t.string('telefone', 20).nullable();
    // Somente o hash da senha é armazenado (bcrypt, a partir da semana 09).
    t.string('senha_hash', 100).notNullable();
    t.enu('perfil', ['tutor', 'ong', 'clinica', 'admin']).notNullable().defaultTo('tutor');
    t.timestamp('criado_em').notNullable().defaultTo(knex.fn.now());
    t.timestamp('atualizado_em').notNullable().defaultTo(knex.fn.now());
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('usuarios');
};
