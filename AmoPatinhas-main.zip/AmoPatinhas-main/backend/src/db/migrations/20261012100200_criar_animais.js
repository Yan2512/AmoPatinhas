/**
 * Animais cadastrados. O "codigo" (ex.: AP-2026-0001) é o identificador público.
 * O microchip é opcional, mas único quando informado: o índice UNIQUE do MySQL
 * aceita vários NULL, o que permite cadastrar animais sem microchip.
 */
exports.up = function (knex) {
  return knex.schema.createTable('animais', (t) => {
    t.increments('id').primary();
    t.string('codigo', 16).notNullable().unique();
    t.string('nome', 80).nullable();
    t.enu('especie', ['cachorro', 'gato', 'outro']).notNullable();
    t.string('raca', 80).nullable();
    t.enu('sexo', ['macho', 'femea', 'desconhecido']).notNullable().defaultTo('desconhecido');
    t.integer('idade_estimada_meses').unsigned().nullable();
    t.date('data_nascimento').nullable();
    t.enu('porte', ['pequeno', 'medio', 'grande']).nullable();
    t.string('cor', 80).nullable();
    t.text('caracteristicas').nullable();
    t.text('descricao').nullable();
    t.enu('situacao', [
      'disponivel',
      'em_tratamento',
      'com_tutor',
      'adotado',
      'perdido',
      'encontrado',
    ]).notNullable();
    t.string('microchip', 20).nullable().unique();
    t.string('bairro', 80).nullable();
    t.string('foto_url', 255).nullable();
    t.date('data_resgate').nullable();
    t.timestamp('criado_em').notNullable().defaultTo(knex.fn.now());
    t.timestamp('atualizado_em').notNullable().defaultTo(knex.fn.now());
    t.index(['situacao']);
    t.index(['especie']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('animais');
};
