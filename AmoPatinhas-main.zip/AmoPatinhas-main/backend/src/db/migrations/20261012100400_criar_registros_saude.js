/** Ficha de saúde em ordem cronológica: cada vacina, castração ou tratamento é um registro. */
exports.up = function (knex) {
  return knex.schema.createTable('registros_saude', (t) => {
    t.increments('id').primary();
    t.integer('animal_id').unsigned().notNullable()
      .references('id').inTable('animais').onDelete('CASCADE');
    t.enu('tipo', ['vacina', 'castracao', 'tratamento', 'doenca', 'alergia', 'procedimento'])
      .notNullable();
    t.string('descricao', 255).notNullable();
    t.date('data').notNullable();
    t.integer('instituicao_id').unsigned().nullable()
      .references('id').inTable('instituicoes').onDelete('SET NULL');
    t.integer('registrado_por').unsigned().nullable()
      .references('id').inTable('usuarios').onDelete('SET NULL');
    t.timestamp('criado_em').notNullable().defaultTo(knex.fn.now());
    t.index(['animal_id', 'data']);
    t.index(['tipo']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('registros_saude');
};
