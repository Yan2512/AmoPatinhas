/** ONGs e clínicas veterinárias. Uma conta de usuário pode gerenciar a instituição. */
exports.up = function (knex) {
  return knex.schema.createTable('instituicoes', (t) => {
    t.increments('id').primary();
    t.integer('usuario_id').unsigned().nullable()
      .references('id').inTable('usuarios').onDelete('SET NULL');
    t.enu('tipo', ['ong', 'clinica']).notNullable();
    t.string('nome', 150).notNullable();
    t.text('descricao').nullable();
    // Serviços separados por ponto e vírgula. Ex.: "Resgate; Adoção; Castração".
    t.string('servicos', 255).nullable();
    t.string('bairro', 80).nullable();
    t.string('endereco', 200).nullable();
    t.string('telefone', 20).nullable();
    t.string('email', 160).nullable();
    t.string('site', 200).nullable();
    t.string('horario', 120).nullable();
    t.decimal('latitude', 9, 6).nullable();
    t.decimal('longitude', 9, 6).nullable();
    t.timestamp('criado_em').notNullable().defaultTo(knex.fn.now());
    t.timestamp('atualizado_em').notNullable().defaultTo(knex.fn.now());
    t.index(['tipo']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('instituicoes');
};
