/**
 * Histórico de responsáveis pelo animal. O vínculo atual é o que tem "fim" nulo.
 * Na adoção, o vínculo com a ONG é encerrado e um novo vínculo com o tutor é criado,
 * preservando o histórico (regra de negócio apresentada na pré-banca).
 */
exports.up = function (knex) {
  return knex.schema.createTable('vinculos_responsavel', (t) => {
    t.increments('id').primary();
    t.integer('animal_id').unsigned().notNullable()
      .references('id').inTable('animais').onDelete('CASCADE');
    t.enu('tipo', ['tutor', 'instituicao']).notNullable();
    t.integer('usuario_id').unsigned().nullable()
      .references('id').inTable('usuarios').onDelete('SET NULL');
    t.integer('instituicao_id').unsigned().nullable()
      .references('id').inTable('instituicoes').onDelete('SET NULL');
    t.date('inicio').notNullable();
    t.date('fim').nullable();
    t.index(['animal_id', 'fim']);
  });
};

exports.down = function (knex) {
  return knex.schema.dropTableIfExists('vinculos_responsavel');
};
