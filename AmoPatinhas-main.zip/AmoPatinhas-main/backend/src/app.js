const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const config = require('./config/env');
const rotas = require('./routes');
const { rotaNaoEncontrada, tratarErros } = require('./middlewares/erros');

const app = express();

app.use(helmet());
app.use(cors({ origin: config.origensCors }));
app.use(express.json({ limit: '100kb' }));

app.use('/api', rotas);

app.use(rotaNaoEncontrada);
app.use(tratarErros);

module.exports = app;
