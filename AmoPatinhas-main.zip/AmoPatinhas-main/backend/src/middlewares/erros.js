const { ErroApp } = require('../utils/erro-app');

/** Mensagens para erros conhecidos do MySQL, que orientam quem está rodando o projeto. */
const ERROS_DE_BANCO = {
  ECONNREFUSED: 'Não foi possível conectar ao MySQL. Verifique se ele está em execução e os dados do .env.',
  ER_ACCESS_DENIED_ERROR: 'O MySQL recusou o usuário ou a senha informados no .env.',
  ER_BAD_DB_ERROR: 'O banco informado em DB_NAME não existe. Crie-o antes de rodar as migrations.',
  ER_NO_SUCH_TABLE: 'As tabelas ainda não existem. Rode "npm run db:migrate" e "npm run db:seed".',
};

function rotaNaoEncontrada(req, res, next) {
  next(new ErroApp(404, `Rota não encontrada: ${req.method} ${req.originalUrl}`));
}

// O Express reconhece o middleware de erro pelos quatro parâmetros.
// eslint-disable-next-line no-unused-vars
function tratarErros(erro, req, res, next) {
  if (erro instanceof ErroApp) {
    return res.status(erro.status).json({ erro: erro.message, detalhes: erro.detalhes });
  }

  if (erro.type === 'entity.parse.failed') {
    return res.status(400).json({ erro: 'O corpo da requisição não é um JSON válido.' });
  }

  if (ERROS_DE_BANCO[erro.code]) {
    console.error(`[banco] ${erro.code}: ${erro.message}`);
    return res.status(503).json({ erro: ERROS_DE_BANCO[erro.code] });
  }

  console.error(erro);
  return res.status(500).json({ erro: 'Erro interno no servidor. Tente novamente em instantes.' });
}

module.exports = { rotaNaoEncontrada, tratarErros };
