const { ErroApp } = require('../utils/erro-app');

/**
 * Valida uma parte da requisição (query, params ou body) com um esquema Zod.
 * O resultado validado fica em req.validado[origem], pois no Express 5
 * o req.query é somente leitura.
 */
function validar(esquema, origem = 'query') {
  return (req, res, next) => {
    const resultado = esquema.safeParse(req[origem] || {});

    if (!resultado.success) {
      const detalhes = resultado.error.issues.map((issue) => ({
        campo: issue.path.join('.'),
        mensagem: issue.message,
      }));
      return next(new ErroApp(400, 'Há dados inválidos na requisição.', detalhes));
    }

    req.validado = { ...req.validado, [origem]: resultado.data };
    return next();
  };
}

module.exports = { validar };
