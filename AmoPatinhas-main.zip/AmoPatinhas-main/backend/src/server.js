const app = require('./app');
const config = require('./config/env');

app.listen(config.porta, () => {
  console.log(`API do AmoPatinhas rodando em http://localhost:${config.porta}/api`);
  if (config.dadosDemonstrativos) {
    console.log('Modo de dados demonstrativos ativo (DADOS_DEMONSTRATIVOS=true).');
  }
});
