const indicadoresService = require('../services/indicadores.service');

async function obter(req, res) {
  res.json(await indicadoresService.obter());
}

module.exports = { obter };
