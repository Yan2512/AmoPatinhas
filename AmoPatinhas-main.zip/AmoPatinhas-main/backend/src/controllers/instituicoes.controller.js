const instituicoesService = require('../services/instituicoes.service');

async function listar(req, res) {
  res.json(await instituicoesService.listar(req.validado.query));
}

module.exports = { listar };
