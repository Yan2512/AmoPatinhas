const saudeService = require('../services/saude.service');

async function verificar(req, res) {
  const situacao = await saudeService.verificar();
  res.status(situacao.banco === 'ok' ? 200 : 503).json(situacao);
}

module.exports = { verificar };
