const animaisService = require('../services/animais.service');

// No Express 5, erros lançados em funções async chegam automaticamente ao middleware de erros.

async function listar(req, res) {
  res.json(await animaisService.listar(req.validado.query));
}

async function obter(req, res) {
  res.json(await animaisService.obterPorCodigo(req.validado.params.codigo));
}

module.exports = { listar, obter };
