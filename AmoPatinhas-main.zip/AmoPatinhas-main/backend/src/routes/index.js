const { Router } = require('express');
const { validar } = require('../middlewares/validar');
const esquemas = require('../validators/esquemas');
const indicadores = require('../controllers/indicadores.controller');
const instituicoes = require('../controllers/instituicoes.controller');
const saude = require('../controllers/saude.controller');
const animaisRoutes = require('./animais.routes');

const router = Router();

router.get('/saude', saude.verificar);
router.get('/indicadores', indicadores.obter);
router.get('/instituicoes', validar(esquemas.listarInstituicoes, 'query'), instituicoes.listar);
router.use('/animais', animaisRoutes);

// Ainda não implementadas (ver cronograma): /auth (semana 09), /adocoes (semana 11),
// /denuncias (semana 12), /admin (semanas 12 e 13).

module.exports = router;
