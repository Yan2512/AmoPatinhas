const { Router } = require('express');
const controller = require('../controllers/animais.controller');
const { validar } = require('../middlewares/validar');
const esquemas = require('../validators/esquemas');

const router = Router();

// GET /api/animais?situacao=disponivel&especie=gato&busca=mel&pagina=1&porPagina=12
router.get('/', validar(esquemas.listarAnimais, 'query'), controller.listar);

// GET /api/animais/AP-2026-0001
router.get('/:codigo', validar(esquemas.codigoAnimal, 'params'), controller.obter);

module.exports = router;
