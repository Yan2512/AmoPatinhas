const { z } = require('zod');
const { ESPECIES, SEXOS, PORTES, SITUACOES_ANIMAL, TIPOS_INSTITUICAO } = require('../domain/valores');

// Mensagens de validação em português
z.config(z.locales.ptBR());

const listarAnimais = z.object({
  situacao: z.enum(SITUACOES_ANIMAL).optional(),
  especie: z.enum(ESPECIES).optional(),
  porte: z.enum(PORTES).optional(),
  sexo: z.enum(SEXOS).optional(),
  busca: z.string().trim().min(1).max(60).optional(),
  // Microchips seguem o padrão ISO 11784 (15 dígitos); modelos antigos usam 9 ou 10.
  microchip: z
    .string()
    .trim()
    .regex(/^\d{9,15}$/, 'O microchip deve ter de 9 a 15 dígitos')
    .optional(),
  pagina: z.coerce.number().int().min(1).default(1),
  porPagina: z.coerce.number().int().min(1).max(48).default(12),
});

const codigoAnimal = z.object({
  codigo: z
    .string()
    .trim()
    .regex(/^AP-\d{4}-\d{4,6}$/i, 'O código deve seguir o formato AP-2026-0001'),
});

const listarInstituicoes = z.object({
  tipo: z.enum(TIPOS_INSTITUICAO).optional(),
});

module.exports = { listarAnimais, codigoAnimal, listarInstituicoes };
