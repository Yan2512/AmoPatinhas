const { z } = require('zod');
const { carregarEnv } = require('./carregar-env');

carregarEnv();

const esquema = z.object({
  PORT: z.coerce.number().int().positive().default(3000),
  CORS_ORIGIN: z.string().default('http://localhost:4200'),
  DB_HOST: z.string().default('localhost'),
  DB_PORT: z.coerce.number().int().positive().default(3306),
  DB_USER: z.string({ error: 'Defina DB_USER no arquivo .env' }).min(1),
  DB_PASSWORD: z.string().default(''),
  DB_NAME: z.string({ error: 'Defina DB_NAME no arquivo .env' }).min(1),
  DADOS_DEMONSTRATIVOS: z
    .enum(['true', 'false'])
    .default('false')
    .transform((valor) => valor === 'true'),
});

const resultado = esquema.safeParse(process.env);

if (!resultado.success) {
  const problemas = resultado.error.issues
    .map((issue) => `- ${issue.path.join('.')}: ${issue.message}`)
    .join('\n');
  throw new Error(`Configuração inválida. Revise o arquivo .env:\n${problemas}`);
}

const env = resultado.data;

module.exports = {
  porta: env.PORT,
  origensCors: env.CORS_ORIGIN.split(',').map((origem) => origem.trim()),
  dadosDemonstrativos: env.DADOS_DEMONSTRATIVOS,
  banco: {
    host: env.DB_HOST,
    port: env.DB_PORT,
    user: env.DB_USER,
    password: env.DB_PASSWORD,
    database: env.DB_NAME,
  },
};
