const fs = require('node:fs');
const path = require('node:path');
const { parseEnv } = require('node:util');

/**
 * Lê o arquivo .env da raiz do back-end com o leitor nativo do Node.js
 * (util.parseEnv), sem dependências extras. Variáveis já definidas no
 * sistema operacional têm prioridade sobre as do arquivo.
 */
function carregarEnv() {
  const arquivo = path.resolve(__dirname, '..', '..', '.env');
  if (!fs.existsSync(arquivo)) return;

  const valores = parseEnv(fs.readFileSync(arquivo, 'utf8'));
  for (const [chave, valor] of Object.entries(valores)) {
    if (process.env[chave] === undefined) {
      process.env[chave] = valor;
    }
  }
}

module.exports = { carregarEnv };
