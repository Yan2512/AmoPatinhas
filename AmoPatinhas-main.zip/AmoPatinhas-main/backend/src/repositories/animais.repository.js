const db = require('../db/conexao');
const { escaparLike } = require('../utils/like');

/** Colunas que podem aparecer em listagens públicas. Microchip e responsável ficam de fora. */
const COLUNAS_RESUMO = [
  'a.codigo',
  'a.nome',
  'a.especie',
  'a.raca',
  'a.sexo',
  'a.idade_estimada_meses',
  'a.porte',
  'a.cor',
  'a.situacao',
  'a.bairro',
  'a.foto_url',
];

function existeRegistro(tipo) {
  return db.raw(
    'exists (select 1 from registros_saude rs where rs.animal_id = a.id and rs.tipo = ?)',
    [tipo],
  );
}

function aplicarFiltros(consulta, filtros) {
  const { situacao, especie, porte, sexo, busca, microchip } = filtros;

  if (situacao) consulta.where('a.situacao', situacao);
  if (especie) consulta.where('a.especie', especie);
  if (porte) consulta.where('a.porte', porte);
  if (sexo) consulta.where('a.sexo', sexo);
  if (microchip) consulta.where('a.microchip', microchip);
  if (busca) {
    const termo = `%${escaparLike(busca)}%`;
    consulta.where((sub) => {
      sub
        .where('a.nome', 'like', termo)
        .orWhere('a.raca', 'like', termo)
        .orWhere('a.bairro', 'like', termo)
        .orWhere('a.codigo', busca.toUpperCase());
    });
  }
  return consulta;
}

async function listar(filtros) {
  const { pagina, porPagina } = filtros;
  const base = aplicarFiltros(db('animais as a'), filtros);

  const [{ total }] = await base.clone().count({ total: '*' });

  const itens = await base
    .clone()
    .select(COLUNAS_RESUMO)
    .select({ castrado: existeRegistro('castracao'), vacinado: existeRegistro('vacina') })
    .orderBy('a.criado_em', 'desc')
    .orderBy('a.id', 'asc')
    .limit(porPagina)
    .offset((pagina - 1) * porPagina);

  return { itens, total: Number(total) };
}

async function buscarPorCodigo(codigo) {
  const animal = await db('animais as a')
    .select(['a.id', ...COLUNAS_RESUMO, 'a.caracteristicas', 'a.descricao', 'a.microchip', 'a.data_resgate'])
    .where('a.codigo', codigo)
    .first();

  if (!animal) return null;

  const [registrosSaude, vinculoAtual] = await Promise.all([
    db('registros_saude')
      .select('tipo', 'descricao', 'data')
      .where('animal_id', animal.id)
      .orderBy('data', 'desc')
      .orderBy('id', 'desc'),
    db('vinculos_responsavel as v')
      .leftJoin('instituicoes as i', 'i.id', 'v.instituicao_id')
      .select(
        'v.tipo',
        'v.inicio',
        'i.nome as instituicao_nome',
        'i.tipo as instituicao_tipo',
        'i.bairro as instituicao_bairro',
        'i.telefone as instituicao_telefone',
        'i.email as instituicao_email',
      )
      .where('v.animal_id', animal.id)
      .whereNull('v.fim')
      .orderBy('v.inicio', 'desc')
      .first(),
  ]);

  return { animal, registrosSaude, vinculoAtual: vinculoAtual || null };
}

module.exports = { listar, buscarPorCodigo };
