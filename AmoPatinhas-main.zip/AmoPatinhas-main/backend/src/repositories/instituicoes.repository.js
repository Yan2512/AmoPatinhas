const db = require('../db/conexao');

async function listar({ tipo }) {
  const consulta = db('instituicoes as i')
    .select(
      'i.id',
      'i.tipo',
      'i.nome',
      'i.descricao',
      'i.servicos',
      'i.bairro',
      'i.endereco',
      'i.telefone',
      'i.email',
      'i.site',
      'i.horario',
    )
    .select({
      animais_sob_cuidado: db('vinculos_responsavel as v')
        .count('*')
        .whereRaw('v.instituicao_id = i.id')
        .whereNull('v.fim'),
    })
    // ONGs primeiro, depois clínicas (em ENUM, o MySQL ordena pela posição do valor, não pelo texto)
    .orderByRaw("case when i.tipo = 'ong' then 0 else 1 end")
    .orderBy('i.nome', 'asc');

  if (tipo) consulta.where('i.tipo', tipo);

  return consulta;
}

module.exports = { listar };
