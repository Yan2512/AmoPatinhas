const db = require('../db/conexao');

function contarAnimaisComRegistro(tipo) {
  return db('registros_saude').countDistinct({ total: 'animal_id' }).where('tipo', tipo).first();
}

async function contar() {
  const [animais, castrados, vacinados, instituicoes] = await Promise.all([
    db('animais')
      .select(
        db.raw('count(*) as total'),
        db.raw("sum(case when situacao = 'disponivel' then 1 else 0 end) as disponiveis"),
        db.raw("sum(case when situacao = 'adotado' then 1 else 0 end) as adotados"),
      )
      .first(),
    contarAnimaisComRegistro('castracao'),
    contarAnimaisComRegistro('vacina'),
    db('instituicoes').select('tipo').count({ total: '*' }).groupBy('tipo'),
  ]);

  const porTipo = Object.fromEntries(instituicoes.map((linha) => [linha.tipo, Number(linha.total)]));

  return {
    animaisCadastrados: Number(animais.total),
    disponiveisAdocao: Number(animais.disponiveis || 0),
    adotados: Number(animais.adotados || 0),
    castrados: Number(castrados.total),
    vacinados: Number(vacinados.total),
    ongs: porTipo.ong || 0,
    clinicas: porTipo.clinica || 0,
  };
}

module.exports = { contar };
