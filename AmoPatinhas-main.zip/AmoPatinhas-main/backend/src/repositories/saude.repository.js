const db = require('../db/conexao');

/** Verifica se o banco responde. Usado pela rota /api/saude. */
async function verificarConexao() {
  await db.raw('select 1');
}

module.exports = { verificarConexao };
