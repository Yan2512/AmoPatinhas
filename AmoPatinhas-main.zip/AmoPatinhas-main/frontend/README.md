# AmoPatinhas: front-end

Interface em Angular 22 com Angular Material. Instruções completas no README da raiz do projeto.

```bash
npm install
npm start            # http://localhost:4200 (precisa da API rodando na porta 3000)
npm run start:demo   # sem back-end, com dados fictícios
npm test             # testes com Vitest
npm run build        # versão de produção em dist/
```
