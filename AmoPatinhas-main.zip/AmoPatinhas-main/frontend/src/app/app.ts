import { Component, ElementRef, viewChild } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Cabecalho } from './core/layout/cabecalho';
import { Rodape } from './core/layout/rodape';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Cabecalho, Rodape],
  templateUrl: './app.html',
  styleUrl: './app.scss',
})
export class App {
  private readonly conteudo = viewChild.required<ElementRef<HTMLElement>>('conteudo');

  /** Link "Pular para o conteúdo": leva o foco do teclado direto para a área principal. */
  pularParaConteudo(evento: Event): void {
    evento.preventDefault();
    this.conteudo().nativeElement.focus();
  }
}
