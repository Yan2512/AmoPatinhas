import { Routes } from '@angular/router';

/**
 * Rotas com carregamento sob demanda (lazy loading): o código de cada página
 * só é baixado quando o usuário a visita.
 * As rotas que apontam para "pending" ainda não foram implementadas e mostram
 * a previsão do cronograma do projeto.
 */
export const routes: Routes = [
  {
    path: '',
    title: 'AmoPatinhas: identificação e adoção responsável em Manaus',
    loadComponent: () => import('./features/home/home').then((m) => m.Home),
  },
  {
    path: 'adocao',
    title: 'Animais para adoção | AmoPatinhas',
    data: { modo: 'adocao' },
    loadComponent: () => import('./features/adoptions/lista-animais').then((m) => m.ListaAnimais),
  },
  {
    path: 'animais',
    title: 'Buscar animal | AmoPatinhas',
    data: { modo: 'busca' },
    loadComponent: () => import('./features/adoptions/lista-animais').then((m) => m.ListaAnimais),
  },
  {
    path: 'animais/:codigo',
    title: 'Ficha do animal | AmoPatinhas',
    loadComponent: () => import('./features/animals/ficha-animal').then((m) => m.FichaAnimal),
  },
  {
    path: 'instituicoes',
    title: 'ONGs e clínicas | AmoPatinhas',
    loadComponent: () =>
      import('./features/organizations/lista-instituicoes').then((m) => m.ListaInstituicoes),
  },
  {
    path: 'entrar',
    title: 'Entrar | AmoPatinhas',
    data: {
      titulo: 'Entrar na sua conta',
      descricao: 'Login com e-mail e senha, recuperação de senha e acesso conforme o perfil (tutor, ONG, clínica ou administrador).',
      previsao: 'semana 09 (19/10 a 25/10)',
    },
    loadComponent: () => import('./features/pending/em-desenvolvimento').then((m) => m.EmDesenvolvimento),
  },
  {
    path: 'cadastrar',
    title: 'Criar conta | AmoPatinhas',
    data: {
      titulo: 'Criar conta',
      descricao: 'Cadastro de tutores, adotantes, ONGs e clínicas, com validação de CPF e e-mail.',
      previsao: 'semana 09 (19/10 a 25/10)',
    },
    loadComponent: () => import('./features/pending/em-desenvolvimento').then((m) => m.EmDesenvolvimento),
  },
  {
    path: 'solicitar-adocao/:codigo',
    title: 'Solicitar adoção | AmoPatinhas',
    data: {
      titulo: 'Solicitar adoção',
      descricao: 'Formulário de interesse, análise pela ONG responsável e acompanhamento do pedido (pendente, em análise, aprovado ou recusado).',
      previsao: 'semana 11 (02/11 a 08/11)',
    },
    loadComponent: () => import('./features/pending/em-desenvolvimento').then((m) => m.EmDesenvolvimento),
  },
  {
    path: 'avisar-encontrado/:codigo',
    title: 'Avisar que encontrei | AmoPatinhas',
    data: {
      titulo: 'Avisar que encontrei este animal',
      descricao: 'Registro de onde e quando o animal foi visto, com aviso ao responsável sem expor os dados pessoais de ninguém.',
      previsao: 'semana 11 (02/11 a 08/11)',
    },
    loadComponent: () => import('./features/pending/em-desenvolvimento').then((m) => m.EmDesenvolvimento),
  },
  {
    path: 'denunciar',
    title: 'Registrar denúncia | AmoPatinhas',
    data: {
      titulo: 'Registrar denúncia',
      descricao: 'Formulário de denúncia de maus-tratos ou abandono, com número de protocolo, anexos e acompanhamento do status. As denúncias não ficam visíveis ao público.',
      previsao: 'semana 12 (09/11 a 15/11)',
    },
    loadComponent: () => import('./features/pending/em-desenvolvimento').then((m) => m.EmDesenvolvimento),
  },
  {
    path: '**',
    title: 'Página não encontrada | AmoPatinhas',
    loadComponent: () => import('./features/not-found/nao-encontrada').then((m) => m.NaoEncontrada),
  },
];
