/** Tipos que representam os dados de animais trocados com a API (/api/animais). */

export type Especie = 'cachorro' | 'gato' | 'outro';
export type Sexo = 'macho' | 'femea' | 'desconhecido';
export type Porte = 'pequeno' | 'medio' | 'grande';
export type Situacao =
  | 'disponivel'
  | 'em_tratamento'
  | 'com_tutor'
  | 'adotado'
  | 'perdido'
  | 'encontrado';
export type TipoRegistroSaude =
  | 'vacina'
  | 'castracao'
  | 'tratamento'
  | 'doenca'
  | 'alergia'
  | 'procedimento';

export interface AnimalResumo {
  codigo: string;
  nome: string | null;
  especie: Especie;
  raca: string | null;
  sexo: Sexo;
  idadeEstimadaMeses: number | null;
  porte: Porte | null;
  cor: string | null;
  situacao: Situacao;
  bairro: string | null;
  fotoUrl: string | null;
  castrado: boolean;
  vacinado: boolean;
}

export interface RegistroSaude {
  tipo: TipoRegistroSaude;
  descricao: string;
  /** Data no formato AAAA-MM-DD */
  data: string;
}

export type Responsavel =
  | { tipo: 'tutor'; desde: string }
  | {
      tipo: 'instituicao';
      desde: string;
      nome: string;
      tipoInstituicao: 'ong' | 'clinica';
      bairro: string | null;
      telefone: string | null;
      email: string | null;
    };

export interface AnimalDetalhe extends AnimalResumo {
  caracteristicas: string | null;
  descricao: string | null;
  dataResgate: string | null;
  possuiMicrochip: boolean;
  /** Apenas os 4 últimos dígitos: o número completo não sai da API. */
  microchipFinal: string | null;
  historicoSaude: RegistroSaude[];
  responsavel: Responsavel | null;
}

export interface FiltrosAnimais {
  situacao?: Situacao;
  especie?: Especie;
  porte?: Porte;
  sexo?: Sexo;
  busca?: string;
  microchip?: string;
  pagina?: number;
  porPagina?: number;
}

export interface Paginacao {
  pagina: number;
  porPagina: number;
  total: number;
  totalPaginas: number;
}

export interface RespostaListaAnimais {
  itens: AnimalResumo[];
  paginacao: Paginacao;
  dadosDemonstrativos: boolean;
}

export interface RespostaAnimal {
  animal: AnimalDetalhe;
  dadosDemonstrativos: boolean;
}
