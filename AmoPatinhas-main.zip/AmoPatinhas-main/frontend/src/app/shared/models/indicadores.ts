export interface Indicadores {
  animaisCadastrados: number;
  disponiveisAdocao: number;
  adotados: number;
  castrados: number;
  vacinados: number;
  ongs: number;
  clinicas: number;
}

export interface RespostaIndicadores {
  indicadores: Indicadores;
  geradoEm: string;
  dadosDemonstrativos: boolean;
}
