/** Formato único de erro usado pelas telas, criado pelo interceptor de erros HTTP. */
export interface ErroApi {
  status: number;
  mensagem: string;
}

export function ehErroApi(valor: unknown): valor is ErroApi {
  return typeof valor === 'object' && valor !== null && 'status' in valor && 'mensagem' in valor;
}
