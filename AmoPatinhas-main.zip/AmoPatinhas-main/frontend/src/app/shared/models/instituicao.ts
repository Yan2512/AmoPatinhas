export type TipoInstituicao = 'ong' | 'clinica';

export interface Instituicao {
  id: number;
  tipo: TipoInstituicao;
  nome: string;
  descricao: string | null;
  servicos: string[];
  bairro: string | null;
  endereco: string | null;
  telefone: string | null;
  email: string | null;
  site: string | null;
  horario: string | null;
  animaisSobCuidado: number;
}

export interface RespostaInstituicoes {
  itens: Instituicao[];
  dadosDemonstrativos: boolean;
}
