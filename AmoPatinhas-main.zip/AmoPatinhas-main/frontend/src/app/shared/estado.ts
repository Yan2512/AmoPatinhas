import { Observable, catchError, map, of, startWith } from 'rxjs';
import { ErroApi, ehErroApi } from './models/erro-api';

/** Estado de uma tela que depende de dados remotos: carregando, pronto ou erro. */
export type Estado<T> =
  | { status: 'carregando' }
  | { status: 'pronto'; dados: T }
  | { status: 'erro'; erro: ErroApi };

export const CARREGANDO = { status: 'carregando' } as const;

/** Envolve uma requisição e devolve o estado correspondente a cada momento. */
export function comEstado<T>(fonte: Observable<T>): Observable<Estado<T>> {
  return fonte.pipe(
    map((dados): Estado<T> => ({ status: 'pronto', dados })),
    catchError((erro: unknown) =>
      of<Estado<T>>({
        status: 'erro',
        erro: ehErroApi(erro) ? erro : { status: 0, mensagem: 'Ocorreu um erro inesperado.' },
      }),
    ),
    startWith<Estado<T>>(CARREGANDO),
  );
}
