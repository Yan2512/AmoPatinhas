/**
 * Textos exibidos para os valores que a API envia em formato técnico.
 * Ex.: "em_tratamento" aparece na tela como "Em tratamento".
 */
export const ROTULOS = {
  especie: { cachorro: 'Cachorro', gato: 'Gato', outro: 'Outra espécie' },
  sexo: { macho: 'Macho', femea: 'Fêmea', desconhecido: 'Sexo não informado' },
  porte: { pequeno: 'Pequeno', medio: 'Médio', grande: 'Grande' },
  situacao: {
    disponivel: 'Disponível para adoção',
    em_tratamento: 'Em tratamento',
    com_tutor: 'Com tutor',
    adotado: 'Adotado',
    perdido: 'Perdido',
    encontrado: 'Encontrado',
  },
  saude: {
    vacina: 'Vacina',
    castracao: 'Castração',
    tratamento: 'Tratamento',
    doenca: 'Doença',
    alergia: 'Alergia',
    procedimento: 'Procedimento',
  },
  instituicao: { ong: 'ONG', clinica: 'Clínica veterinária' },
} as const;

export type GrupoRotulo = keyof typeof ROTULOS;

export function rotular(grupo: GrupoRotulo, valor: string | null | undefined): string {
  if (!valor) return '';
  const textos = ROTULOS[grupo] as Record<string, string>;
  return textos[valor] ?? valor;
}
