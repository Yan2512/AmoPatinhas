import { Component } from '@angular/core';

/** Logotipo: a plaquinha de identificação com a pata, seguida do nome. */
@Component({
  selector: 'app-marca',
  template: `
    <svg class="simbolo" viewBox="0 0 64 64" aria-hidden="true" focusable="false">
      <circle cx="32" cy="9" r="6" fill="none" stroke="#c58b2a" stroke-width="4" />
      <rect x="9" y="14" width="46" height="46" rx="16" fill="#1f5c45" />
      <circle cx="32" cy="22" r="3.2" fill="#fff" />
      <g fill="#fff" transform="translate(16 58) scale(0.0333)">
        <path
          d="M169.86-485Q132-485 106-511.14t-26-64Q80-613 106.14-639t64-26Q208-665 234-638.86t26 64Q260-537 233.86-511t-64 26ZM291-681.14q-26-26.14-26-64T291.14-809q26.14-26 64-26T419-808.86q26 26.14 26 64T418.86-681q-26.14 26-64 26T291-681.14Zm250 0q-26-26.14-26-64T541.14-809q26.14-26 64-26T669-808.86q26 26.140 26 64T668.86-681q-26.14 26-64 26T541-681.14ZM789.86-485Q752-485 726-511.14t-26-64Q700-613 726.14-639t64-26Q828-665 854-638.86t26 64Q880-537 853.86-511t-64 26ZM266-75q-42 0-69-31.53-27-31.52-27-74.47 0-42 25.5-74.5T250-318q22-22 41-46.5t36-50.5q29-44 65-82t88-38q52 0 88.5 38t65.5 83q17 26 35.5 50t40.5 46q29 30 54.5 62.5T790-181q0 42.95-27 74.47Q736-75 694-75q-54 0-107-9t-107-9q-54 0-107 9t-107 9Z"
        />
      </g>
    </svg>
    <span class="nome">AmoPatinhas</span>
  `,
  styles: `
    :host {
      display: inline-flex;
      align-items: center;
      gap: 0.55rem;
    }
    .simbolo {
      width: 2.4rem;
      height: 2.4rem;
      flex: none;
    }
    .nome {
      font-family: var(--fonte-titulo);
      font-weight: 760;
      font-size: 1.4rem;
      letter-spacing: -0.02em;
      color: var(--mata-escura);
    }
    :host(.clara) .nome {
      color: #fff;
    }
  `,
})
export class Marca {}
