import { Component, computed, input } from '@angular/core';
import { MatIcon } from '@angular/material/icon';
import { RouterLink } from '@angular/router';
import { AnimalResumo } from '../models/animal';
import { IdadePipe } from '../pipes/idade.pipe';
import { RotuloPipe } from '../pipes/rotulo.pipe';
import { rotular } from '../rotulos';

/**
 * A "plaquinha" de identificação: o cartão que representa um animal.
 * Imita a medalha da coleira, com argola, nome e o código gravado.
 */
@Component({
  selector: 'app-plaquinha',
  imports: [RouterLink, MatIcon, IdadePipe, RotuloPipe],
  templateUrl: './plaquinha.html',
  styleUrl: './plaquinha.scss',
  host: { '[class.grande]': "tamanho() === 'grande'" },
})
export class Plaquinha {
  readonly animal = input.required<AnimalResumo>();
  readonly tamanho = input<'normal' | 'grande'>('normal');
  /** Desligado na ficha do animal, onde a plaquinha não precisa levar a outra página. */
  readonly comLink = input(true);
  readonly mostrarSituacao = input(false);

  readonly nomeExibido = computed(() => this.animal().nome ?? 'Sem nome');

  /** Ex.: "Gato, fêmea". O sexo é omitido quando não foi informado. */
  readonly especieESexo = computed(() => {
    const { especie, sexo } = this.animal();
    const textoEspecie = rotular('especie', especie);
    return sexo === 'desconhecido' ? textoEspecie : `${textoEspecie}, ${rotular('sexo', sexo).toLowerCase()}`;
  });

  /** "Castrado" ou "Castrada", conforme o sexo do animal. */
  readonly selos = computed(() => {
    const animal = this.animal();
    const final = animal.sexo === 'femea' ? 'a' : 'o';
    const selos: string[] = [];
    if (animal.castrado) selos.push(`Castrad${final}`);
    if (animal.vacinado) selos.push(`Vacinad${final}`);
    return selos;
  });
}
