import { Component, input } from '@angular/core';
import { MatIcon } from '@angular/material/icon';


@Component({
  selector: 'app-aviso-demonstrativo',
  imports: [MatIcon],
  template: `
    <p class="aviso">
      <mat-icon svgIcon="info" aria-hidden="true" />
      <span><strong>Dados demonstrativos.</strong> {{ texto() }}</span>
    </p>
  `,
  styles: `
    .aviso {
      display: flex;
      gap: 0.5rem;
      align-items: flex-start;
      margin: 1rem 0 0;
      font-size: 0.92rem;
      color: var(--pedra);
      max-width: 62ch;
    }
    mat-icon {
      width: 1.25rem;
      height: 1.25rem;
      flex: none;
      margin-top: 0.1rem;
      color: var(--latao);
    }
  `,
})
export class AvisoDemonstrativo {
  readonly texto = input('Os animais e instituições exibidos são fictícios e servem para testar o sistema.');
}
