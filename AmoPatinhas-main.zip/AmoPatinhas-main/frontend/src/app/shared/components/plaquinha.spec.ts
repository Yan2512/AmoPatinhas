import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { provideRouter } from '@angular/router';
import { registrarIcones } from '../../core/icones/registrar-icones';
import { AnimalResumo } from '../models/animal';
import { Plaquinha } from './plaquinha';

const ACAI: AnimalResumo = {
  codigo: 'AP-2026-0002',
  nome: 'Açaí',
  especie: 'gato',
  raca: null,
  sexo: 'femea',
  idadeEstimadaMeses: 8,
  porte: 'pequeno',
  cor: 'Preta',
  situacao: 'disponivel',
  bairro: 'Flores',
  fotoUrl: null,
  castrado: true,
  vacinado: false,
};

describe('Plaquinha', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [Plaquinha],
      providers: [provideRouter([]), provideHttpClient()],
    });
    TestBed.runInInjectionContext(registrarIcones);
  });

  it('mostra nome, código, idade e o selo no feminino', async () => {
    const fixture = TestBed.createComponent(Plaquinha);
    fixture.componentRef.setInput('animal', ACAI);
    await fixture.whenStable();
    const texto = (fixture.nativeElement as HTMLElement).textContent ?? '';

    expect(texto).toContain('Açaí');
    expect(texto).toContain('AP-2026-0002');
    expect(texto).toContain('8 meses');
    expect(texto).toContain('Gato, fêmea');
    expect(texto).toContain('Castrada');
    expect(texto).not.toContain('Vacinada');
  });

  it('leva para a ficha do animal pelo código', async () => {
    const fixture = TestBed.createComponent(Plaquinha);
    fixture.componentRef.setInput('animal', ACAI);
    await fixture.whenStable();
    const link = (fixture.nativeElement as HTMLElement).querySelector('a');

    expect(link?.getAttribute('href')).toBe('/animais/AP-2026-0002');
  });

  it('chama de "Sem nome" o animal sem nome registrado', async () => {
    const fixture = TestBed.createComponent(Plaquinha);
    fixture.componentRef.setInput('animal', { ...ACAI, nome: null });
    await fixture.whenStable();

    expect((fixture.nativeElement as HTMLElement).querySelector('h3')?.textContent).toContain('Sem nome');
  });
});
