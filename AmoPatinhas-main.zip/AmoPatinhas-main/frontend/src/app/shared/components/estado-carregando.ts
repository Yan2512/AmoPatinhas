import { Component, input } from '@angular/core';
import { MatProgressSpinner } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-estado-carregando',
  imports: [MatProgressSpinner],
  template: `
    <div class="estado" role="status">
      <mat-progress-spinner mode="indeterminate" diameter="34" strokeWidth="4" aria-hidden="true" />
      <p>{{ texto() }}</p>
    </div>
  `,
  styles: `
    .estado {
      display: flex;
      align-items: center;
      gap: 0.9rem;
      padding: 2.5rem 0;
      color: var(--pedra);
    }
    p {
      margin: 0;
    }
  `,
})
export class EstadoCarregando {
  readonly texto = input('Carregando');
}
