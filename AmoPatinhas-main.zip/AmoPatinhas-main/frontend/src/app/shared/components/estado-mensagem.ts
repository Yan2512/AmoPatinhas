import { Component, input } from '@angular/core';
import { MatIcon } from '@angular/material/icon';

/**
 * Mensagem para telas vazias ou com erro. Sempre diz o que aconteceu e o que fazer,
 * com as ações (botões) passadas como conteúdo.
 */
@Component({
  selector: 'app-estado-mensagem',
  imports: [MatIcon],
  template: `
    <div class="estado" [class.erro]="tom() === 'erro'" [attr.role]="tom() === 'erro' ? 'alert' : null">
      <mat-icon [svgIcon]="icone()" aria-hidden="true" />
      <div>
        <h2 class="titulo">{{ titulo() }}</h2>
        @if (texto()) {
          <p>{{ texto() }}</p>
        }
        <div class="acoes"><ng-content /></div>
      </div>
    </div>
  `,
  styles: `
    .estado {
      display: flex;
      gap: 1rem;
      align-items: flex-start;
      padding: 2rem 0;
      max-width: 40rem;
    }
    mat-icon {
      width: 2.25rem;
      height: 2.25rem;
      flex: none;
      color: var(--mata);
    }
    .erro mat-icon {
      color: var(--alerta);
    }
    .titulo {
      font-size: 1.3rem;
      margin: 0.2rem 0 0.35rem;
    }
    p {
      margin: 0 0 1rem;
      color: var(--pedra);
    }
    .acoes:empty {
      display: none;
    }
  `,
})
export class EstadoMensagem {
  readonly icone = input('info');
  readonly titulo = input.required<string>();
  readonly texto = input<string | null>(null);
  readonly tom = input<'neutro' | 'erro'>('neutro');
}
