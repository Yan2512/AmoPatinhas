import { Pipe, PipeTransform } from '@angular/core';

/** Converte a idade estimada em meses para um texto curto. Ex.: 26 → "2 anos". */
export function descreverIdade(meses: number | null | undefined): string {
  if (meses === null || meses === undefined) return 'Idade não informada';
  if (meses < 1) return 'Menos de 1 mês';
  if (meses < 12) return meses === 1 ? '1 mês' : `${meses} meses`;
  const anos = Math.floor(meses / 12);
  return anos === 1 ? '1 ano' : `${anos} anos`;
}

@Pipe({ name: 'idade' })
export class IdadePipe implements PipeTransform {
  transform(meses: number | null | undefined): string {
    return descreverIdade(meses);
  }
}
