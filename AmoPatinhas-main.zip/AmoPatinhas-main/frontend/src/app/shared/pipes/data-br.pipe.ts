import { Pipe, PipeTransform } from '@angular/core';

/**
 * Formata datas "AAAA-MM-DD" como "DD/MM/AAAA" sem converter fuso horário.
 * (Com o DatePipe, "2026-03-12" seria lido como meia-noite UTC e, em Manaus (UTC-4),
 * apareceria como 11/03.)
 */
export function formatarDataBr(data: string | null | undefined): string {
  if (!data) return '';
  const [ano, mes, dia] = data.slice(0, 10).split('-');
  return ano && mes && dia ? `${dia}/${mes}/${ano}` : data;
}

@Pipe({ name: 'dataBr' })
export class DataBrPipe implements PipeTransform {
  transform(data: string | null | undefined): string {
    return formatarDataBr(data);
  }
}
