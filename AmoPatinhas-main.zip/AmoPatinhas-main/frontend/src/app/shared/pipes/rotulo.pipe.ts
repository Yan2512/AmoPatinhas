import { Pipe, PipeTransform } from '@angular/core';
import { GrupoRotulo, rotular } from '../rotulos';

/** Uso: {{ animal.situacao | rotulo: 'situacao' }} */
@Pipe({ name: 'rotulo' })
export class RotuloPipe implements PipeTransform {
  transform(valor: string | null | undefined, grupo: GrupoRotulo): string {
    return rotular(grupo, valor);
  }
}
