import { formatarDataBr } from './data-br.pipe';
import { descreverIdade } from './idade.pipe';
import { RotuloPipe } from './rotulo.pipe';

describe('descreverIdade', () => {
  it('mostra meses para animais com menos de um ano', () => {
    expect(descreverIdade(1)).toBe('1 mês');
    expect(descreverIdade(8)).toBe('8 meses');
  });

  it('mostra anos completos a partir de 12 meses', () => {
    expect(descreverIdade(12)).toBe('1 ano');
    expect(descreverIdade(26)).toBe('2 anos');
  });

  it('avisa quando a idade não foi informada', () => {
    expect(descreverIdade(null)).toBe('Idade não informada');
  });
});

describe('formatarDataBr', () => {
  it('converte AAAA-MM-DD para DD/MM/AAAA sem mudar o dia por causa do fuso', () => {
    expect(formatarDataBr('2026-03-12')).toBe('12/03/2026');
  });

  it('devolve texto vazio quando não há data', () => {
    expect(formatarDataBr(null)).toBe('');
  });
});

describe('RotuloPipe', () => {
  const pipe = new RotuloPipe();

  it('traduz valores técnicos da API para textos da interface', () => {
    expect(pipe.transform('em_tratamento', 'situacao')).toBe('Em tratamento');
    expect(pipe.transform('femea', 'sexo')).toBe('Fêmea');
  });

  it('mantém o valor original quando não conhece o rótulo', () => {
    expect(pipe.transform('desconhecido_novo', 'situacao')).toBe('desconhecido_novo');
  });
});
