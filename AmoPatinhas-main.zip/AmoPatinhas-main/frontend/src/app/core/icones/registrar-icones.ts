import { inject } from '@angular/core';
import { MatIconRegistry } from '@angular/material/icon';
import { DomSanitizer } from '@angular/platform-browser';
import { ICONES } from './icones';

/** Registra os ícones SVG no Angular Material. Uso: <mat-icon svgIcon="pets" />. */
export function registrarIcones(): void {
  const registro = inject(MatIconRegistry);
  const sanitizador = inject(DomSanitizer);
  for (const [nome, svg] of Object.entries(ICONES)) {
    // Conteúdo estático escrito no próprio código: seguro para confiar.
    registro.addSvgIconLiteral(nome, sanitizador.bypassSecurityTrustHtml(svg));
  }
}
