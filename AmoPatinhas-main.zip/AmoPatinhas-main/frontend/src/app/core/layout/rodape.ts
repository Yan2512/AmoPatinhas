import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { Marca } from '../../shared/components/marca';

@Component({
  selector: 'app-rodape',
  imports: [RouterLink, Marca],
  template: `
    <footer class="rodape">
      <div class="conteiner grade">
        <div class="sobre">
          <app-marca class="clara" />
          <p>Identificação, saúde e adoção responsável de animais em Manaus.</p>
        </div>
        <nav aria-label="Rodapé">
          <ul>
            <li><a routerLink="/adocao">Adoção</a></li>
            <li><a routerLink="/animais">Buscar animal</a></li>
            <li><a routerLink="/instituicoes">ONGs e clínicas</a></li>
            <li><a routerLink="/denunciar">Denunciar maus-tratos</a></li>
          </ul>
        </nav>
        <p class="projeto">
          Trabalho de Conclusão de Curso de Sistemas de Informação, Centro Universitário Fametro, Manaus.
        </p>
      </div>
    </footer>
  `,
  styles: `
    .rodape {
      background: var(--mata-escura);
      color: #dbe9e1;
      padding-block: 3rem 2.5rem;
    }
    .grade {
      display: grid;
      gap: 2rem;
    }
    .sobre p {
      margin: 0.75rem 0 0;
    }
    ul {
      list-style: none;
      margin: 0;
      padding: 0;
      display: grid;
      gap: 0.5rem;
    }
    a {
      color: #fff;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
      color: #fff;
    }
    .projeto {
      font-size: 0.9rem;
      color: #b9cfc3;
      margin: 0;
    }
    @media (min-width: 800px) {
      .grade {
        grid-template-columns: 1.4fr 1fr;
      }
      .projeto {
        grid-column: 1 / -1;
        padding-top: 1.5rem;
        border-top: 1px solid rgb(255 255 255 / 0.15);
      }
    }
  `,
})
export class Rodape {}
