import { Component, signal } from '@angular/core';
import { MatButton, MatIconButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { Marca } from '../../shared/components/marca';

@Component({
  selector: 'app-cabecalho',
  imports: [RouterLink, RouterLinkActive, MatButton, MatIconButton, MatIcon, Marca],
  templateUrl: './cabecalho.html',
  styleUrl: './cabecalho.scss',
})
export class Cabecalho {
  readonly menuAberto = signal(false);

  readonly links = [
    { rota: '/adocao', texto: 'Adoção', exato: false },
    { rota: '/animais', texto: 'Buscar animal', exato: true },
    { rota: '/instituicoes', texto: 'ONGs e clínicas', exato: false },
    { rota: '/denunciar', texto: 'Denunciar', exato: false },
  ];

  alternarMenu(): void {
    this.menuAberto.update((aberto) => !aberto);
  }

  fecharMenu(): void {
    this.menuAberto.set(false);
  }
}
