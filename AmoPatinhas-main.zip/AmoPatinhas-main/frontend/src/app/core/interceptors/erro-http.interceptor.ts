import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';
import { environment } from '../../../environments/environment';
import { ErroApi } from '../../shared/models/erro-api';

/**
 * Converte qualquer erro HTTP em um ErroApi com uma mensagem clara,
 * para que as telas não precisem conhecer os detalhes do HttpClient.
 */
export const erroHttpInterceptor: HttpInterceptorFn = (requisicao, proximo) =>
  proximo(requisicao).pipe(
    catchError((erro: HttpErrorResponse) => throwError(() => paraErroApi(erro))),
  );

export function paraErroApi(erro: HttpErrorResponse): ErroApi {
  if (erro.status === 0) {
    return {
      status: 0,
      mensagem: environment.production
        ? 'Não foi possível conectar ao servidor. Verifique sua internet e tente novamente.'
        : 'A API não respondeu. Confira se o back-end está rodando (npm run dev, na pasta backend).',
    };
  }

  const mensagemDaApi = typeof erro.error?.erro === 'string' ? erro.error.erro : null;
  if (mensagemDaApi) {
    return { status: erro.status, mensagem: mensagemDaApi };
  }

  if (erro.status === 404) {
    return { status: 404, mensagem: 'O conteúdo procurado não foi encontrado.' };
  }

  return { status: erro.status, mensagem: 'O servidor encontrou um problema. Tente novamente em instantes.' };
}
