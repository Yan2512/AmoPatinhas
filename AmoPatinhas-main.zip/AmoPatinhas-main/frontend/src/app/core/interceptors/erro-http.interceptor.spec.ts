import { HttpErrorResponse } from '@angular/common/http';
import { paraErroApi } from './erro-http.interceptor';

describe('paraErroApi', () => {
  it('explica quando a API não responde', () => {
    const erro = paraErroApi(new HttpErrorResponse({ status: 0 }));
    expect(erro.status).toBe(0);
    expect(erro.mensagem).toContain('back-end');
  });

  it('usa a mensagem enviada pela API quando existe', () => {
    const erro = paraErroApi(
      new HttpErrorResponse({ status: 404, error: { erro: 'Nenhum animal encontrado com o código AP-2026-9999.' } }),
    );
    expect(erro).toEqual({ status: 404, mensagem: 'Nenhum animal encontrado com o código AP-2026-9999.' });
  });

  it('tem uma mensagem padrão para falhas sem detalhes', () => {
    const erro = paraErroApi(new HttpErrorResponse({ status: 500 }));
    expect(erro.mensagem).toContain('Tente novamente');
  });
});
