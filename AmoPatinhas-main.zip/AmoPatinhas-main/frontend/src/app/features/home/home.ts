import { DecimalPipe } from '@angular/common';
import { Component, inject } from '@angular/core';
import { toSignal } from '@angular/core/rxjs-interop';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatFormField, MatHint, MatLabel } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { Router, RouterLink } from '@angular/router';
import { Subject, startWith, switchMap } from 'rxjs';
import { AnimaisDados, IndicadoresDados, InstituicoesDados } from '../../data/contratos';
import { AvisoDemonstrativo } from '../../shared/components/aviso-demonstrativo';
import { EstadoCarregando } from '../../shared/components/estado-carregando';
import { EstadoMensagem } from '../../shared/components/estado-mensagem';
import { Plaquinha } from '../../shared/components/plaquinha';
import { CARREGANDO, Estado, comEstado } from '../../shared/estado';
import { RespostaListaAnimais } from '../../shared/models/animal';
import { RespostaIndicadores } from '../../shared/models/indicadores';
import { RespostaInstituicoes } from '../../shared/models/instituicao';
import { RotuloPipe } from '../../shared/pipes/rotulo.pipe';

const CODIGO_AP = /^AP-\d{4}-\d{4,6}$/i;

@Component({
  selector: 'app-home',
  imports: [
    ReactiveFormsModule,
    RouterLink,
    DecimalPipe,
    MatButton,
    MatFormField,
    MatLabel,
    MatHint,
    MatInput,
    MatIcon,
    Plaquinha,
    EstadoCarregando,
    EstadoMensagem,
    AvisoDemonstrativo,
    RotuloPipe,
  ],
  templateUrl: './home.html',
  styleUrl: './home.scss',
})
export class Home {
  private readonly router = inject(Router);
  private readonly animaisDados = inject(AnimaisDados);
  private readonly indicadoresDados = inject(IndicadoresDados);
  private readonly instituicoesDados = inject(InstituicoesDados);
  private readonly recarregarVitrine$ = new Subject<void>();

  readonly busca = new FormControl('', { nonNullable: true, validators: [Validators.maxLength(60)] });

  /** Uma única consulta: o primeiro animal vai para o destaque, os seis seguintes para a vitrine. */
  readonly vitrine = toSignal(
    this.recarregarVitrine$.pipe(
      startWith(undefined),
      switchMap(() => comEstado(this.animaisDados.listar({ situacao: 'disponivel', porPagina: 7 }))),
    ),
    { initialValue: CARREGANDO as Estado<RespostaListaAnimais> },
  );

  readonly indicadores = toSignal(comEstado(this.indicadoresDados.obter()), {
    initialValue: CARREGANDO as Estado<RespostaIndicadores>,
  });

  readonly instituicoes = toSignal(comEstado(this.instituicoesDados.listar()), {
    initialValue: CARREGANDO as Estado<RespostaInstituicoes>,
  });

  recarregarVitrine(): void {
    this.recarregarVitrine$.next();
  }

  /** Código AP abre a ficha direto; qualquer outro termo vai para a busca. */
  buscar(): void {
    if (this.busca.invalid) return;
    const termo = this.busca.value.trim();

    if (!termo) {
      this.router.navigate(['/animais']);
    } else if (CODIGO_AP.test(termo)) {
      this.router.navigate(['/animais', termo.toUpperCase()]);
    } else {
      this.router.navigate(['/animais'], { queryParams: { busca: termo } });
    }
  }
}
