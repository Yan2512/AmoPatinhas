import { Component, computed, inject } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { MatButton } from '@angular/material/button';
import { MatButtonToggle, MatButtonToggleGroup } from '@angular/material/button-toggle';
import { MatIcon } from '@angular/material/icon';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, combineLatest, startWith, switchMap } from 'rxjs';
import { InstituicoesDados } from '../../data/contratos';
import { AvisoDemonstrativo } from '../../shared/components/aviso-demonstrativo';
import { EstadoCarregando } from '../../shared/components/estado-carregando';
import { EstadoMensagem } from '../../shared/components/estado-mensagem';
import { CARREGANDO, Estado, comEstado } from '../../shared/estado';
import { RespostaInstituicoes, TipoInstituicao } from '../../shared/models/instituicao';
import { RotuloPipe } from '../../shared/pipes/rotulo.pipe';

type FiltroTipo = TipoInstituicao | 'todas';

@Component({
  selector: 'app-lista-instituicoes',
  imports: [
    MatButton,
    MatButtonToggleGroup,
    MatButtonToggle,
    MatIcon,
    EstadoCarregando,
    EstadoMensagem,
    AvisoDemonstrativo,
    RotuloPipe,
  ],
  templateUrl: './lista-instituicoes.html',
  styleUrl: './lista-instituicoes.scss',
})
export class ListaInstituicoes {
  private readonly rota = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly dados = inject(InstituicoesDados);
  private readonly recarregar$ = new Subject<void>();

  private readonly parametros = toSignal(this.rota.queryParamMap, { requireSync: true });

  readonly tipo = computed<FiltroTipo>(() => {
    const tipo = this.parametros().get('tipo');
    return tipo === 'ong' || tipo === 'clinica' ? tipo : 'todas';
  });

  readonly estado = toSignal(
    combineLatest([toObservable(this.tipo), this.recarregar$.pipe(startWith(undefined))]).pipe(
      switchMap(([tipo]) => comEstado(this.dados.listar(tipo === 'todas' ? undefined : tipo))),
    ),
    { initialValue: CARREGANDO as Estado<RespostaInstituicoes> },
  );

  filtrar(tipo: FiltroTipo): void {
    this.router.navigate([], {
      relativeTo: this.rota,
      queryParams: { tipo: tipo === 'todas' ? null : tipo },
    });
  }

  recarregar(): void {
    this.recarregar$.next();
  }
}
