import { Component, input } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { RouterLink } from '@angular/router';

/**
 * Página para funcionalidades ainda não implementadas.
 * Os textos vêm do "data" de cada rota em app.routes.ts, com a previsão do cronograma.
 */
@Component({
  selector: 'app-em-desenvolvimento',
  imports: [RouterLink, MatButton, MatIcon],
  template: `
    <div class="conteiner pagina">
      <mat-icon svgIcon="construction" class="icone" aria-hidden="true" />
      <h1>{{ titulo() }}</h1>
      <p class="lide">Esta parte do AmoPatinhas ainda está em desenvolvimento.</p>
      @if (previsao()) {
        <p>Previsão no cronograma do projeto: <strong>{{ previsao() }}</strong>.</p>
      }
      @if (descricao()) {
        <h2>O que vai ter aqui</h2>
        <p>{{ descricao() }}</p>
      }
      <div class="acoes">
        @if (codigo()) {
          <a mat-flat-button [routerLink]="['/animais', codigo()]">Voltar para a ficha do animal</a>
        }
        <a mat-stroked-button routerLink="/">Ir para a página inicial</a>
      </div>
    </div>
  `,
  styles: `
    .pagina {
      padding-block: clamp(3rem, 8vw, 6rem);
      max-width: 48rem;
      margin-inline: auto;
    }
    .icone {
      width: 3rem;
      height: 3rem;
      color: var(--latao);
      margin-bottom: 1rem;
    }
    .lide {
      font-size: 1.2rem;
      color: var(--pedra);
    }
    h2 {
      font-size: 1.3rem;
      margin-top: 2rem;
    }
    .acoes {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      margin-top: 2rem;
    }
  `,
})
export class EmDesenvolvimento {
  // Preenchidos pelo "data" e pelos parâmetros da rota (withComponentInputBinding)
  readonly titulo = input('Em desenvolvimento');
  readonly descricao = input('');
  readonly previsao = input('');
  readonly codigo = input<string>();
}
