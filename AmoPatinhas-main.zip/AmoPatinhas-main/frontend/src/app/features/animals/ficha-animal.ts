import { Location } from '@angular/common';
import { Component, effect, inject, input } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { Title } from '@angular/platform-browser';
import { Router, RouterLink } from '@angular/router';
import { Subject, combineLatest, startWith, switchMap } from 'rxjs';
import { AnimaisDados } from '../../data/contratos';
import { AvisoDemonstrativo } from '../../shared/components/aviso-demonstrativo';
import { EstadoCarregando } from '../../shared/components/estado-carregando';
import { EstadoMensagem } from '../../shared/components/estado-mensagem';
import { Plaquinha } from '../../shared/components/plaquinha';
import { CARREGANDO, Estado, comEstado } from '../../shared/estado';
import { RespostaAnimal, TipoRegistroSaude } from '../../shared/models/animal';
import { DataBrPipe } from '../../shared/pipes/data-br.pipe';
import { IdadePipe } from '../../shared/pipes/idade.pipe';
import { RotuloPipe } from '../../shared/pipes/rotulo.pipe';

const ICONES_SAUDE: Record<TipoRegistroSaude, string> = {
  vacina: 'vaccines',
  castracao: 'health-and-safety',
  tratamento: 'medication',
  doenca: 'sick',
  alergia: 'allergy',
  procedimento: 'medical-services',
};

/** Ficha completa do animal: identificação, características, saúde e responsável. */
@Component({
  selector: 'app-ficha-animal',
  imports: [
    RouterLink,
    MatButton,
    MatIcon,
    Plaquinha,
    EstadoCarregando,
    EstadoMensagem,
    AvisoDemonstrativo,
    RotuloPipe,
    IdadePipe,
    DataBrPipe,
  ],
  templateUrl: './ficha-animal.html',
  styleUrl: './ficha-animal.scss',
})
export class FichaAnimal {
  /** Parâmetro :codigo da rota (withComponentInputBinding). */
  readonly codigo = input.required<string>();

  private readonly dados = inject(AnimaisDados);
  private readonly titulo = inject(Title);
  private readonly location = inject(Location);
  private readonly router = inject(Router);
  private readonly recarregar$ = new Subject<void>();

  readonly estado = toSignal(
    combineLatest([toObservable(this.codigo), this.recarregar$.pipe(startWith(undefined))]).pipe(
      switchMap(([codigo]) => comEstado(this.dados.obter(codigo))),
    ),
    { initialValue: CARREGANDO as Estado<RespostaAnimal> },
  );

  constructor() {
    effect(() => {
      const estado = this.estado();
      if (estado.status === 'pronto') {
        const animal = estado.dados.animal;
        this.titulo.setTitle(`${animal.nome ?? animal.codigo} | AmoPatinhas`);
      }
    });
  }

  iconeSaude(tipo: TipoRegistroSaude): string {
    return ICONES_SAUDE[tipo] ?? 'medical-services';
  }

  voltar(): void {
    if (window.history.length > 1) {
      this.location.back();
    } else {
      this.router.navigate(['/animais']);
    }
  }

  recarregar(): void {
    this.recarregar$.next();
  }
}
