import { Component } from '@angular/core';
import { MatButton } from '@angular/material/button';
import { MatIcon } from '@angular/material/icon';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-nao-encontrada',
  imports: [RouterLink, MatButton, MatIcon],
  template: `
    <div class="conteiner pagina">
      <mat-icon svgIcon="search-off" class="icone" aria-hidden="true" />
      <h1>Página não encontrada</h1>
      <p class="lide">O endereço digitado não existe no AmoPatinhas. Confira o link ou escolha um destino abaixo.</p>
      <div class="acoes">
        <a mat-flat-button routerLink="/">Ir para a página inicial</a>
        <a mat-stroked-button routerLink="/animais">Buscar um animal</a>
      </div>
    </div>
  `,
  styles: `
    .pagina {
      padding-block: clamp(3rem, 8vw, 6rem);
      max-width: 48rem;
      margin-inline: auto;
    }
    .icone {
      width: 3rem;
      height: 3rem;
      color: var(--mata);
      margin-bottom: 1rem;
    }
    .lide {
      font-size: 1.2rem;
      color: var(--pedra);
    }
    .acoes {
      display: flex;
      flex-wrap: wrap;
      gap: 0.75rem;
      margin-top: 2rem;
    }
  `,
})
export class NaoEncontrada {}
