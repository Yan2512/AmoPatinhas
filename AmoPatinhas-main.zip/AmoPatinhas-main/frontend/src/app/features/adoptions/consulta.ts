import { ParamMap } from '@angular/router';
import { Especie, FiltrosAnimais, Porte, Sexo, Situacao } from '../../shared/models/animal';

export type ModoLista = 'adocao' | 'busca';

export const ESPECIES: Especie[] = ['cachorro', 'gato', 'outro'];
export const PORTES: Porte[] = ['pequeno', 'medio', 'grande'];
export const SEXOS: Sexo[] = ['macho', 'femea'];
export const SITUACOES: Situacao[] = [
  'disponivel',
  'em_tratamento',
  'com_tutor',
  'adotado',
  'perdido',
  'encontrado',
];
export const TAMANHOS_PAGINA = [12, 24, 48];

const MICROCHIP = /^\d{9,15}$/;

function valorPermitido<T extends string>(valor: string | null, permitidos: readonly T[]): T | undefined {
  return valor && (permitidos as readonly string[]).includes(valor) ? (valor as T) : undefined;
}

/** Microchip só é buscado pelo número completo (9 a 15 dígitos). */
export function ehMicrochip(termo: string): boolean {
  return MICROCHIP.test(termo);
}

/**
 * Converte os parâmetros da URL (?especie=gato&pagina=2) nos filtros enviados à API.
 * Valores desconhecidos são ignorados, então uma URL editada à mão não quebra a tela.
 * Na página de adoção, a situação é sempre "disponivel".
 */
export function montarConsulta(parametros: ParamMap, modo: ModoLista): FiltrosAnimais {
  const pagina = Math.max(1, Math.floor(Number(parametros.get('pagina'))) || 1);
  const tamanho = Number(parametros.get('porPagina'));
  const consulta: FiltrosAnimais = {
    pagina,
    porPagina: TAMANHOS_PAGINA.includes(tamanho) ? tamanho : TAMANHOS_PAGINA[0],
    situacao: modo === 'adocao' ? 'disponivel' : valorPermitido(parametros.get('situacao'), SITUACOES),
    especie: valorPermitido(parametros.get('especie'), ESPECIES),
    porte: valorPermitido(parametros.get('porte'), PORTES),
    sexo: valorPermitido(parametros.get('sexo'), SEXOS),
  };

  const busca = parametros.get('busca')?.trim().slice(0, 60);
  const microchip = parametros.get('microchip')?.trim();
  if (microchip && ehMicrochip(microchip)) {
    consulta.microchip = microchip;
  } else if (busca) {
    if (ehMicrochip(busca)) consulta.microchip = busca;
    else consulta.busca = busca;
  }

  return consulta;
}
