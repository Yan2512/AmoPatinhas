import { Component, computed, effect, inject, input } from '@angular/core';
import { takeUntilDestroyed, toObservable, toSignal } from '@angular/core/rxjs-interop';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { MatButton } from '@angular/material/button';
import { MatOption } from '@angular/material/core';
import { MatFormField, MatLabel, MatSuffix } from '@angular/material/form-field';
import { MatIcon } from '@angular/material/icon';
import { MatInput } from '@angular/material/input';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSelect } from '@angular/material/select';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject, combineLatest, debounceTime, startWith, switchMap } from 'rxjs';
import { AnimaisDados } from '../../data/contratos';
import { AvisoDemonstrativo } from '../../shared/components/aviso-demonstrativo';
import { EstadoCarregando } from '../../shared/components/estado-carregando';
import { EstadoMensagem } from '../../shared/components/estado-mensagem';
import { Plaquinha } from '../../shared/components/plaquinha';
import { CARREGANDO, Estado, comEstado } from '../../shared/estado';
import { RespostaListaAnimais } from '../../shared/models/animal';
import { RotuloPipe } from '../../shared/pipes/rotulo.pipe';
import {
  ESPECIES,
  ModoLista,
  PORTES,
  SEXOS,
  SITUACOES,
  TAMANHOS_PAGINA,
  ehMicrochip,
  montarConsulta,
} from './consulta';

/**
 * Lista de animais com filtros e paginação. Atende duas rotas:
 * /adocao (somente disponíveis) e /animais (busca geral, qualquer situação).
 * Os filtros ficam na URL, então a busca pode ser compartilhada ou recarregada.
 */
@Component({
  selector: 'app-lista-animais',
  imports: [
    ReactiveFormsModule,
    MatFormField,
    MatLabel,
    MatSuffix,
    MatInput,
    MatSelect,
    MatOption,
    MatButton,
    MatIcon,
    MatPaginator,
    Plaquinha,
    EstadoCarregando,
    EstadoMensagem,
    AvisoDemonstrativo,
    RotuloPipe,
  ],
  templateUrl: './lista-animais.html',
  styleUrl: './lista-animais.scss',
})
export class ListaAnimais {
  /** Vem do "data" da rota (withComponentInputBinding). */
  readonly modo = input<ModoLista>('busca');

  private readonly rota = inject(ActivatedRoute);
  private readonly router = inject(Router);
  private readonly dados = inject(AnimaisDados);
  private readonly recarregar$ = new Subject<void>();

  readonly opcoes = { especies: ESPECIES, portes: PORTES, sexos: SEXOS, situacoes: SITUACOES };
  readonly tamanhosPagina = TAMANHOS_PAGINA;

  readonly filtros = new FormGroup({
    busca: new FormControl('', { nonNullable: true, validators: [Validators.maxLength(60)] }),
    situacao: new FormControl('', { nonNullable: true }),
    especie: new FormControl('', { nonNullable: true }),
    porte: new FormControl('', { nonNullable: true }),
    sexo: new FormControl('', { nonNullable: true }),
  });

  private readonly parametros = toSignal(this.rota.queryParamMap, { requireSync: true });
  readonly consulta = computed(() => montarConsulta(this.parametros(), this.modo()));

  readonly estado = toSignal(
    combineLatest([toObservable(this.consulta), this.recarregar$.pipe(startWith(undefined))]).pipe(
      switchMap(([consulta]) => comEstado(this.dados.listar(consulta))),
    ),
    { initialValue: CARREGANDO as Estado<RespostaListaAnimais> },
  );

  readonly temFiltros = computed(() => {
    const { busca, microchip, especie, porte, sexo, situacao } = this.consulta();
    const situacaoEscolhida = this.modo() === 'busca' && !!situacao;
    return !!(busca || microchip || especie || porte || sexo || situacaoEscolhida);
  });

  /** Texto lido por leitores de tela sempre que o resultado muda. */
  readonly mensagemResultado = computed(() => {
    const estado = this.estado();
    if (estado.status === 'carregando') return 'Procurando animais…';
    if (estado.status === 'erro') return '';
    const total = estado.dados.paginacao.total;
    return total === 1 ? '1 animal encontrado' : `${total} animais encontrados`;
  });

  constructor() {
    // URL → formulário (ao abrir a página ou usar o botão voltar do navegador)
    effect(() => {
      const consulta = this.consulta();
      const buscaAtual = this.filtros.controls.busca.value.trim();
      const buscaDaUrl = consulta.busca ?? consulta.microchip ?? '';
      this.filtros.patchValue(
        {
          busca: buscaAtual === buscaDaUrl ? this.filtros.controls.busca.value : buscaDaUrl,
          situacao: this.modo() === 'busca' ? (consulta.situacao ?? '') : '',
          especie: consulta.especie ?? '',
          porte: consulta.porte ?? '',
          sexo: consulta.sexo ?? '',
        },
        { emitEvent: false },
      );
    });

    // Formulário → URL (a busca por texto espera o usuário parar de digitar)
    this.filtros.valueChanges.pipe(debounceTime(350), takeUntilDestroyed()).subscribe(() => this.atualizarUrl());
  }

  atualizarUrl(): void {
    if (this.filtros.invalid) return;
    const valor = this.filtros.getRawValue();
    const termo = valor.busca.trim();
    const microchip = termo && ehMicrochip(termo);

    this.router.navigate([], {
      relativeTo: this.rota,
      replaceUrl: true,
      queryParams: {
        busca: termo && !microchip ? termo : null,
        microchip: microchip ? termo : null,
        situacao: this.modo() === 'busca' && valor.situacao ? valor.situacao : null,
        especie: valor.especie || null,
        porte: valor.porte || null,
        sexo: valor.sexo || null,
        pagina: null,
        porPagina: this.parametros().get('porPagina'),
      },
    });
  }

  mudarPagina(evento: PageEvent): void {
    this.router.navigate([], {
      relativeTo: this.rota,
      queryParamsHandling: 'merge',
      queryParams: { pagina: evento.pageIndex + 1, porPagina: evento.pageSize },
    });
  }

  limparFiltros(): void {
    this.filtros.reset({ busca: '', situacao: '', especie: '', porte: '', sexo: '' }, { emitEvent: false });
    this.router.navigate([], { relativeTo: this.rota, queryParams: {} });
  }

  recarregar(): void {
    this.recarregar$.next();
  }
}
