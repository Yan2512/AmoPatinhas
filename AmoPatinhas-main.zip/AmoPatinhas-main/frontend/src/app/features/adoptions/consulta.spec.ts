import { convertToParamMap } from '@angular/router';
import { montarConsulta } from './consulta';

describe('montarConsulta (URL → filtros da API)', () => {
  it('na página de adoção sempre filtra por animais disponíveis', () => {
    const consulta = montarConsulta(convertToParamMap({ situacao: 'adotado' }), 'adocao');
    expect(consulta.situacao).toBe('disponivel');
  });

  it('na busca geral aceita a situação escolhida', () => {
    const consulta = montarConsulta(convertToParamMap({ situacao: 'perdido' }), 'busca');
    expect(consulta.situacao).toBe('perdido');
  });

  it('ignora valores que não existem, sem quebrar a tela', () => {
    const consulta = montarConsulta(
      convertToParamMap({ especie: 'dinossauro', pagina: '-3', porPagina: '1000' }),
      'busca',
    );
    expect(consulta.especie).toBeUndefined();
    expect(consulta.pagina).toBe(1);
    expect(consulta.porPagina).toBe(12);
  });

  it('trata números de 9 a 15 dígitos como microchip', () => {
    const consulta = montarConsulta(convertToParamMap({ busca: '999000000000001' }), 'busca');
    expect(consulta.microchip).toBe('999000000000001');
    expect(consulta.busca).toBeUndefined();
  });

  it('envia textos comuns como busca por nome ou bairro', () => {
    const consulta = montarConsulta(convertToParamMap({ busca: '  Compensa ' }), 'busca');
    expect(consulta.busca).toBe('Compensa');
  });
});
