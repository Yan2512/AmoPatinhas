import { Observable } from 'rxjs';
import { FiltrosAnimais, RespostaAnimal, RespostaListaAnimais } from '../shared/models/animal';
import { RespostaIndicadores } from '../shared/models/indicadores';
import { RespostaInstituicoes, TipoInstituicao } from '../shared/models/instituicao';

/*
 * Contratos da camada de dados.
 * Os componentes dependem destas classes abstratas, nunca da implementação.
 * Em app.config.ts, provideDados() escolhe a implementação HTTP (API real)
 * ou a simulada (dados fictícios), conforme o ambiente.
 */

export abstract class AnimaisDados {
  abstract listar(filtros: FiltrosAnimais): Observable<RespostaListaAnimais>;
  abstract obter(codigo: string): Observable<RespostaAnimal>;
}

export abstract class IndicadoresDados {
  abstract obter(): Observable<RespostaIndicadores>;
}

export abstract class InstituicoesDados {
  abstract listar(tipo?: TipoInstituicao): Observable<RespostaInstituicoes>;
}
