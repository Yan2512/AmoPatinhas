import { Injectable } from '@angular/core';
import { Observable, delay, of } from 'rxjs';
import { RespostaIndicadores } from '../../shared/models/indicadores';
import { IndicadoresDados } from '../contratos';
import { ANIMAIS_SIMULADOS, INSTITUICOES_SIMULADAS } from './base-simulada';

/** Calcula os indicadores a partir dos dados fictícios, como a API faz com o banco. */
@Injectable()
export class IndicadoresSimulados extends IndicadoresDados {
  obter(): Observable<RespostaIndicadores> {
    const animais = ANIMAIS_SIMULADOS;
    return of({
      indicadores: {
        animaisCadastrados: animais.length,
        disponiveisAdocao: animais.filter((a) => a.situacao === 'disponivel').length,
        adotados: animais.filter((a) => a.situacao === 'adotado').length,
        castrados: animais.filter((a) => a.castrado).length,
        vacinados: animais.filter((a) => a.vacinado).length,
        ongs: INSTITUICOES_SIMULADAS.filter((i) => i.tipo === 'ong').length,
        clinicas: INSTITUICOES_SIMULADAS.filter((i) => i.tipo === 'clinica').length,
      },
      geradoEm: new Date().toISOString(),
      dadosDemonstrativos: true,
    }).pipe(delay(300));
  }
}
