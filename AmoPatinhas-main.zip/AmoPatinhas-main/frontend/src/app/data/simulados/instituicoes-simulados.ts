import { Injectable } from '@angular/core';
import { Observable, delay, of } from 'rxjs';
import { RespostaInstituicoes, TipoInstituicao } from '../../shared/models/instituicao';
import { InstituicoesDados } from '../contratos';
import { INSTITUICOES_SIMULADAS } from './base-simulada';

@Injectable()
export class InstituicoesSimulados extends InstituicoesDados {
  listar(tipo?: TipoInstituicao): Observable<RespostaInstituicoes> {
    const itens = tipo ? INSTITUICOES_SIMULADAS.filter((item) => item.tipo === tipo) : INSTITUICOES_SIMULADAS;
    return of({ itens, dadosDemonstrativos: true }).pipe(delay(300));
  }
}
