import { AnimalDetalhe } from '../../shared/models/animal';
import { Instituicao } from '../../shared/models/instituicao';

/*
 * DADOS FICTÍCIOS usados apenas no modo demonstração (npm run start:demo)
 * e nos testes. Não representam animais, pessoas ou instituições reais.
 */

export const INSTITUICOES_SIMULADAS: Instituicao[] = [
  {
    id: 1, tipo: 'ong', nome: 'Abrigo Exemplo Rio Negro', bairro: 'Compensa', endereco: null,
    descricao: 'Acolhe cães e gatos resgatados na Zona Oeste e organiza feiras de adoção.',
    servicos: ['Resgate', 'Adoção', 'Lar temporário'], horario: 'Segunda a sábado, das 8h às 17h',
    telefone: '(92) 90000-0001', email: 'contato.rionegro@example.org', site: null, animaisSobCuidado: 3,
  },
  {
    id: 2, tipo: 'ong', nome: 'ONG Exemplo Patas do Tarumã', bairro: 'Tarumã', endereco: null,
    descricao: 'Resgata animais em situação de rua e mantém mutirões de castração.',
    servicos: ['Resgate', 'Castração', 'Educação'], horario: 'Terça a sábado, das 9h às 16h',
    telefone: '(92) 90000-0002', email: 'contato.taruma@example.org', site: null, animaisSobCuidado: 2,
  },
  {
    id: 5, tipo: 'clinica', nome: 'Clínica Veterinária Exemplo Adrianópolis', bairro: 'Adrianópolis',
    endereco: 'Rua Exemplo, 100', descricao: 'Clínica geral para cães e gatos.',
    servicos: ['Consultas', 'Vacinação', 'Castração'], horario: 'Segunda a sexta, das 8h às 18h',
    telefone: '(92) 90000-0005', email: 'clinica.adrianopolis@example.org', site: null, animaisSobCuidado: 0,
  },
];

function animal(dados: Partial<AnimalDetalhe> & Pick<AnimalDetalhe, 'codigo' | 'especie' | 'situacao'>): AnimalDetalhe {
  return {
    nome: null, raca: null, sexo: 'desconhecido', idadeEstimadaMeses: null, porte: null, cor: null,
    bairro: null, fotoUrl: null, castrado: false, vacinado: false, caracteristicas: null, descricao: null,
    dataResgate: null, possuiMicrochip: false, microchipFinal: null, historicoSaude: [], responsavel: null,
    ...dados,
  };
}

const ABRIGO = {
  tipo: 'instituicao' as const, desde: '2026-03-12', nome: 'Abrigo Exemplo Rio Negro',
  tipoInstituicao: 'ong' as const, bairro: 'Compensa', telefone: '(92) 90000-0001',
  email: 'contato.rionegro@example.org',
};

export const ANIMAIS_SIMULADOS: AnimalDetalhe[] = [
  animal({
    codigo: 'AP-2026-0001', nome: 'Tucumã', especie: 'cachorro', sexo: 'macho', idadeEstimadaMeses: 24,
    porte: 'medio', cor: 'Caramelo', situacao: 'disponivel', bairro: 'Compensa', castrado: true, vacinado: true,
    descricao: 'Brincalhão, se dá bem com outros cães e com crianças.', dataResgate: '2026-03-12',
    possuiMicrochip: true, microchipFinal: '0001', responsavel: ABRIGO,
    historicoSaude: [
      { tipo: 'castracao', descricao: 'Castração', data: '2026-04-02' },
      { tipo: 'vacina', descricao: 'V10 (polivalente canina)', data: '2026-03-20' },
    ],
  }),
  animal({
    codigo: 'AP-2026-0002', nome: 'Açaí', especie: 'gato', sexo: 'femea', idadeEstimadaMeses: 8,
    porte: 'pequeno', cor: 'Preta', situacao: 'disponivel', bairro: 'Flores', castrado: true, vacinado: true,
    descricao: 'Tranquila e curiosa. Gosta de colo.', responsavel: { ...ABRIGO, desde: '2026-06-02' },
  }),
  animal({
    codigo: 'AP-2026-0003', nome: 'Jambu', especie: 'cachorro', sexo: 'macho', idadeEstimadaMeses: 48,
    porte: 'grande', cor: 'Preto e branco', situacao: 'disponivel', bairro: 'Tarumã', castrado: true,
    vacinado: true, descricao: 'Calmo, ótimo para casas com quintal.', responsavel: ABRIGO,
  }),
  animal({
    codigo: 'AP-2026-0009', nome: 'Paçoca', especie: 'outro', raca: 'Coelho mestiço', sexo: 'femea',
    idadeEstimadaMeses: 12, porte: 'pequeno', cor: 'Bege', situacao: 'disponivel', bairro: 'Flores',
    responsavel: ABRIGO,
  }),
  animal({
    codigo: 'AP-2026-0011', nome: 'Piri', especie: 'gato', sexo: 'macho', idadeEstimadaMeses: 4,
    porte: 'pequeno', situacao: 'em_tratamento', bairro: 'Tarumã', responsavel: ABRIGO,
  }),
  animal({
    codigo: 'AP-2026-0013', nome: 'Caju', especie: 'cachorro', sexo: 'macho', idadeEstimadaMeses: 26,
    porte: 'medio', situacao: 'adotado', bairro: 'Flores', castrado: true, vacinado: true,
    possuiMicrochip: true, microchipFinal: '0013', responsavel: { tipo: 'tutor', desde: '2026-08-09' },
  }),
];

/** Microchips completos existem só aqui, para simular a busca exata feita pela API. */
export const MICROCHIPS_SIMULADOS: Record<string, string> = {
  '999000000000001': 'AP-2026-0001',
  '999000000000013': 'AP-2026-0013',
};
