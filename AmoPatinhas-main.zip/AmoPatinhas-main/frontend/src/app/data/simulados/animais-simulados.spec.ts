import { firstValueFrom } from 'rxjs';
import { ErroApi } from '../../shared/models/erro-api';
import { AnimaisSimulados } from './animais-simulados';

describe('AnimaisSimulados (modo demonstração)', () => {
  const dados = new AnimaisSimulados();

  it('filtra por situação e marca a resposta como demonstrativa', async () => {
    const resposta = await firstValueFrom(dados.listar({ situacao: 'disponivel' }));
    expect(resposta.itens.length).toBeGreaterThan(0);
    expect(resposta.itens.every((animal) => animal.situacao === 'disponivel')).toBe(true);
    expect(resposta.dadosDemonstrativos).toBe(true);
  });

  it('pagina os resultados', async () => {
    const resposta = await firstValueFrom(dados.listar({ pagina: 2, porPagina: 2 }));
    expect(resposta.itens.length).toBe(2);
    expect(resposta.paginacao.pagina).toBe(2);
    expect(resposta.paginacao.totalPaginas).toBe(Math.ceil(resposta.paginacao.total / 2));
  });

  it('encontra um animal pelo microchip completo', async () => {
    const resposta = await firstValueFrom(dados.listar({ microchip: '999000000000013' }));
    expect(resposta.itens.map((animal) => animal.codigo)).toEqual(['AP-2026-0013']);
  });

  it('responde com erro 404 para código inexistente', async () => {
    await expect(firstValueFrom(dados.obter('AP-2026-9999'))).rejects.toMatchObject<Partial<ErroApi>>({
      status: 404,
    });
  });
});
