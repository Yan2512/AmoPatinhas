import { Observable, delay, of, throwError } from 'rxjs';
import {
  AnimalDetalhe,
  AnimalResumo,
  FiltrosAnimais,
  RespostaAnimal,
  RespostaListaAnimais,
} from '../../shared/models/animal';
import { ErroApi } from '../../shared/models/erro-api';
import { AnimaisDados } from '../contratos';
import { ANIMAIS_SIMULADOS, MICROCHIPS_SIMULADOS } from './base-simulada';

const ATRASO_MS = 350;

function paraResumo(animal: AnimalDetalhe): AnimalResumo {
  const { codigo, nome, especie, raca, sexo, idadeEstimadaMeses, porte, cor, situacao, bairro, fotoUrl, castrado, vacinado } =
    animal;
  return { codigo, nome, especie, raca, sexo, idadeEstimadaMeses, porte, cor, situacao, bairro, fotoUrl, castrado, vacinado };
}

/**
 * Implementação em memória que imita o comportamento de GET /api/animais.
 * Recebe a lista no construtor para que os testes possam usar dados próprios.
 */
export class AnimaisSimulados extends AnimaisDados {
  constructor(private readonly base: AnimalDetalhe[] = ANIMAIS_SIMULADOS) {
    super();
  }

  listar(filtros: FiltrosAnimais): Observable<RespostaListaAnimais> {
    const pagina = filtros.pagina ?? 1;
    const porPagina = filtros.porPagina ?? 12;
    const busca = filtros.busca?.trim().toLowerCase();

    const filtrados = this.base.filter((animal) => {
      if (filtros.situacao && animal.situacao !== filtros.situacao) return false;
      if (filtros.especie && animal.especie !== filtros.especie) return false;
      if (filtros.porte && animal.porte !== filtros.porte) return false;
      if (filtros.sexo && animal.sexo !== filtros.sexo) return false;
      if (filtros.microchip && MICROCHIPS_SIMULADOS[filtros.microchip] !== animal.codigo) return false;
      if (busca) {
        const campos = [animal.nome, animal.raca, animal.bairro].map((campo) => (campo ?? '').toLowerCase());
        const achou = campos.some((campo) => campo.includes(busca)) || animal.codigo.toLowerCase() === busca;
        if (!achou) return false;
      }
      return true;
    });

    const inicio = (pagina - 1) * porPagina;
    return of({
      itens: filtrados.slice(inicio, inicio + porPagina).map(paraResumo),
      paginacao: {
        pagina,
        porPagina,
        total: filtrados.length,
        totalPaginas: Math.max(1, Math.ceil(filtrados.length / porPagina)),
      },
      dadosDemonstrativos: true,
    }).pipe(delay(ATRASO_MS));
  }

  obter(codigo: string): Observable<RespostaAnimal> {
    const animal = this.base.find((item) => item.codigo === codigo.toUpperCase());
    if (!animal) {
      const erro: ErroApi = {
        status: 404,
        mensagem: `Nenhum animal encontrado com o código ${codigo.toUpperCase()}.`,
      };
      return throwError(() => erro).pipe(delay(ATRASO_MS));
    }
    return of({ animal, dadosDemonstrativos: true }).pipe(delay(ATRASO_MS));
  }
}
