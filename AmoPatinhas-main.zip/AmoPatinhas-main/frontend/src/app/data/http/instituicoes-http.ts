import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RespostaInstituicoes, TipoInstituicao } from '../../shared/models/instituicao';
import { InstituicoesDados } from '../contratos';

@Injectable()
export class InstituicoesHttp extends InstituicoesDados {
  private readonly http = inject(HttpClient);

  listar(tipo?: TipoInstituicao): Observable<RespostaInstituicoes> {
    const params = tipo ? new HttpParams().set('tipo', tipo) : undefined;
    return this.http.get<RespostaInstituicoes>(`${environment.apiUrl}/instituicoes`, { params });
  }
}
