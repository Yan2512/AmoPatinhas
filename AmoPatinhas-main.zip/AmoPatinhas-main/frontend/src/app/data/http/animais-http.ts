import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { FiltrosAnimais, RespostaAnimal, RespostaListaAnimais } from '../../shared/models/animal';
import { AnimaisDados } from '../contratos';

@Injectable()
export class AnimaisHttp extends AnimaisDados {
  private readonly http = inject(HttpClient);
  private readonly url = `${environment.apiUrl}/animais`;

  listar(filtros: FiltrosAnimais): Observable<RespostaListaAnimais> {
    let params = new HttpParams();
    for (const [chave, valor] of Object.entries(filtros)) {
      if (valor !== undefined && valor !== null && valor !== '') {
        params = params.set(chave, String(valor));
      }
    }
    return this.http.get<RespostaListaAnimais>(this.url, { params });
  }

  obter(codigo: string): Observable<RespostaAnimal> {
    return this.http.get<RespostaAnimal>(`${this.url}/${encodeURIComponent(codigo)}`);
  }
}
