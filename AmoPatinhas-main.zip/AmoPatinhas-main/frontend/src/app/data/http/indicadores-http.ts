import { HttpClient } from '@angular/common/http';
import { Injectable, inject } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../environments/environment';
import { RespostaIndicadores } from '../../shared/models/indicadores';
import { IndicadoresDados } from '../contratos';

@Injectable()
export class IndicadoresHttp extends IndicadoresDados {
  private readonly http = inject(HttpClient);

  obter(): Observable<RespostaIndicadores> {
    return this.http.get<RespostaIndicadores>(`${environment.apiUrl}/indicadores`);
  }
}
