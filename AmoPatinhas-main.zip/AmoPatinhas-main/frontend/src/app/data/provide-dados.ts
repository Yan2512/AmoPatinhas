import { Provider } from '@angular/core';
import { environment } from '../../environments/environment';
import { AnimaisDados, IndicadoresDados, InstituicoesDados } from './contratos';
import { AnimaisHttp } from './http/animais-http';
import { IndicadoresHttp } from './http/indicadores-http';
import { InstituicoesHttp } from './http/instituicoes-http';
import { AnimaisSimulados } from './simulados/animais-simulados';
import { IndicadoresSimulados } from './simulados/indicadores-simulados';
import { InstituicoesSimulados } from './simulados/instituicoes-simulados';

/**
 * Escolhe de onde vêm os dados: da API real (padrão) ou da memória (modo demonstração).
 * Trocar uma pela outra não exige mudar nenhum componente.
 */
export function provideDados(usarDadosSimulados = environment.usarDadosSimulados): Provider[] {
  if (usarDadosSimulados) {
    return [
      { provide: AnimaisDados, useFactory: () => new AnimaisSimulados() },
      { provide: IndicadoresDados, useClass: IndicadoresSimulados },
      { provide: InstituicoesDados, useClass: InstituicoesSimulados },
    ];
  }
  return [
    { provide: AnimaisDados, useClass: AnimaisHttp },
    { provide: IndicadoresDados, useClass: IndicadoresHttp },
    { provide: InstituicoesDados, useClass: InstituicoesHttp },
  ];
}
