import { provideHttpClient } from '@angular/common/http';
import { TestBed } from '@angular/core/testing';
import { provideRouter } from '@angular/router';
import { App } from './app';
import { registrarIcones } from './core/icones/registrar-icones';

describe('App (estrutura da página)', () => {
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [App],
      providers: [provideRouter([]), provideHttpClient()],
    }).compileComponents();
    TestBed.runInInjectionContext(registrarIcones);
  });

  it('oferece o link "Pular para o conteúdo" e a área principal', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const html = fixture.nativeElement as HTMLElement;

    expect(html.querySelector('a.pular-conteudo')?.textContent).toContain('Pular para o conteúdo');
    expect(html.querySelector('main#conteudo')).toBeTruthy();
  });

  it('exibe o menu principal com os links de navegação', async () => {
    const fixture = TestBed.createComponent(App);
    await fixture.whenStable();
    const links = Array.from(
      (fixture.nativeElement as HTMLElement).querySelectorAll('nav[aria-label="Principal"] a'),
    ).map((link) => link.textContent?.trim());

    expect(links).toEqual(['Adoção', 'Buscar animal', 'ONGs e clínicas', 'Denunciar', 'Entrar']);
  });
});
