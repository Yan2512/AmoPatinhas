/**
 * Configuração de desenvolvimento (npm start).
 * O ng serve encaminha /api para http://localhost:3000 (ver proxy.conf.json).
 */
export const environment = {
  production: false,
  apiUrl: '/api',
  usarDadosSimulados: false,
};
