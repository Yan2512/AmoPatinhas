/** Configuração de produção (ng build). A API deve responder no mesmo domínio, em /api. */
export const environment = {
  production: true,
  apiUrl: '/api',
  usarDadosSimulados: false,
};
