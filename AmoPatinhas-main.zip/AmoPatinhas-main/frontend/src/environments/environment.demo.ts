/**
 * Modo demonstração (npm run start:demo): roda o front-end sem back-end,
 * com dados fictícios em memória. As telas exibem o aviso "Dados demonstrativos".
 */
export const environment = {
  production: false,
  apiUrl: '/api',
  usarDadosSimulados: true,
};
